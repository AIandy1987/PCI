/* ��@�ɦW��:PciUser.c
   �{���]�p:PIN-HSIEN CHIANG */
#include "PciUser.h"
#include <stdio.h>
#include <string.h>

HANDLE pcis_open(void) {
    return CreateFileW(PCIControlSys_DEVICE_PATH, GENERIC_READ | GENERIC_WRITE,
                       0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
}

void pcis_close(HANDLE hdevice) {
    if(hdevice!=NULL && hdevice!=INVALID_HANDLE_VALUE) CloseHandle(hdevice);
}

static BOOL pcisioctl(HANDLE h, DWORD code, void *buffer, DWORD size, DWORD *returned) {
    if(h==INVALID_HANDLE_VALUE || h==NULL) {
        SetLastError(ERROR_INVALID_HANDLE);
        return FALSE;
    }
    return DeviceIoControl(h, code, buffer, size, buffer, size, returned, NULL);
}

BOOL pcis_pciread8(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, BYTE *value) {
    PCI_BDF_REQUEST r;
    DWORD n = 0;

    if(!value) return FALSE;
    r.Bus=bus, r.Device=dev, r.Function=fun, r.Offset=off;
    if(!pcisioctl(h, IOCTL_PCI_READ8, &r, sizeof(r), &n)) return FALSE;
    *value = r.Bus; //METHOD_BUFFERED�@��SystemBuffer�BDriver�N���G�g�bbuffer�}�Y
    return n>=sizeof(BYTE);
}

BOOL pcis_pciread16(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, WORD *value) {
    BYTE b[sizeof(PCI_BDF_REQUEST)];
    DWORD n = 0;
    PCI_BDF_REQUEST *r = (PCI_BDF_REQUEST*)b;

    if(!value) return FALSE;
    r->Bus=bus, r->Device=dev, r->Function=fun, r->Offset=off;
    if(!DeviceIoControl(h, IOCTL_PCI_READ16, b, sizeof(*r), b, sizeof(WORD), &n, NULL)) return FALSE;
    memcpy(value, b, sizeof(WORD));
    return n>=sizeof(WORD);
}

BOOL pcis_pciread32(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, DWORD *value) {
    BYTE b[sizeof(PCI_BDF_REQUEST)];
    DWORD n = 0;
    PCI_BDF_REQUEST *r = (PCI_BDF_REQUEST*)b;

    if(!value) return FALSE;
    r->Bus=bus, r->Device=dev, r->Function=fun, r->Offset=off;
    if(!DeviceIoControl(h, IOCTL_PCI_READ32, b, sizeof(*r), b, sizeof(DWORD), &n, NULL)) return FALSE;
    memcpy(value, b, sizeof(DWORD));
    return n>=sizeof(DWORD);
}

BOOL pcis_pciwrite8(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, BYTE value) {
    PCI_BDF_WRITE8_REQUEST r = {bus, dev, fun, off, value};
    DWORD n = 0;
    return DeviceIoControl(h, IOCTL_PCI_WRITE8, &r, sizeof(r), NULL, 0, &n, NULL);
}

BOOL pcis_pciwrite16(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, WORD value) {
    PCI_BDF_WRITE16_REQUEST r;
    DWORD n = 0;
    r.Bus=bus, r.Device=dev, r.Function=fun, r.Offset=off, r.Value=value;
    return DeviceIoControl(h, IOCTL_PCI_WRITE16, &r, sizeof(r), NULL, 0, &n, NULL);
}

BOOL pcis_pciwrite32(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, DWORD value) {
    PCI_BDF_WRITE32_REQUEST r;
    DWORD n = 0;
    r.Bus=bus, r.Device=dev, r.Function=fun, r.Offset=off, r.Value=value;
    return DeviceIoControl(h, IOCTL_PCI_WRITE32, &r, sizeof(r), NULL, 0, &n, NULL);
}

BOOL pcis_pciscan(HANDLE h, PCI_SCAN_RESULT *result) {
    DWORD n = 0;
    BYTE dummy = 0;

    if(!result) return FALSE;
    ZeroMemory(result, sizeof(*result));
    return DeviceIoControl(h, IOCTL_PCI_SCAN, &dummy, sizeof(dummy), result, sizeof(*result), &n, NULL);
}

BOOL pcis_cpuid(HANDLE h, DWORD leaf, CPUID_RESULT *result) {
    BYTE buffer[sizeof(CPUID_RESULT)];
    DWORD n = 0;

    if(!result) return FALSE;
    ZeroMemory(buffer, sizeof(buffer));
    memcpy(buffer, &leaf, sizeof(leaf));
    if(!DeviceIoControl(h, IOCTL_CPU_CPUID, buffer, sizeof(leaf), buffer,
       sizeof(buffer), &n, NULL)) return FALSE;
    memcpy(result, buffer, sizeof(*result));
    return n >= sizeof(CPUID_RESULT);
}

BOOL pcis_cpuidex(HANDLE h, DWORD leaf, DWORD subleaf, CPUID_RESULT *result) {
    BYTE buffer[sizeof(CPUID_RESULT)];
    CPUID_EX_REQUEST req;
    DWORD n = 0;

    if(!result) return FALSE;
    req.Leaf=leaf, req.SubLeaf=subleaf;
    ZeroMemory(buffer, sizeof(buffer));
    memcpy(buffer, &req, sizeof(req));
    if(!DeviceIoControl(h, IOCTL_CPU_CPUID_EX, buffer, sizeof(req), buffer,
       sizeof(buffer), &n, NULL)) return FALSE;
    memcpy(result, buffer, sizeof(*result));
    return n>=sizeof(CPUID_RESULT);
}

BOOL pcis_rdtsc(HANDLE h, ULONGLONG *tsc) {
    DWORD n = 0;
    ULONGLONG v = 0;

    if(!tsc) return FALSE;
    if(!DeviceIoControl(h, IOCTL_CPU_TSC, NULL, 0, &v, sizeof(v), &n, NULL)) return FALSE;
    *tsc = v;
    return n>=sizeof(v);
}

BOOL pcis_rdtscp(HANDLE h, TSC_AUX_RESULT *result) {
    DWORD n = 0;
    TSC_AUX_RESULT r;

    if(!result) return FALSE;
    if(!DeviceIoControl(h, IOCTL_CPU_RDTSCP, NULL, 0, &r, sizeof(r), &n, NULL)) return FALSE;
    *result = r;
    return n>=sizeof(r);
}

BOOL pcis_readcontrolregs(HANDLE h, CPU_CONTROL_REGS_RESULT *result) {
    DWORD n = 0;
    CPU_CONTROL_REGS_RESULT r;

    if(!result) return FALSE;
    if(!DeviceIoControl(h, IOCTL_CPU_CONTROL_REGS, NULL, 0, &r, sizeof(r), &r, NULL)) return FALSE;
    *result = r;
    return n>=sizeof(r);
}

BOOL pcis_msrread(HANDLE h, DWORD msr, ULONGLONG *value) {
    BYTE buffer[sizeof(ULONGLONG)];
    MSR_REQUEST req;
    DWORD n = 0;

    if(!value) return FALSE;
    req.Msr = msr;
    ZeroMemory(buffer, sizeof(buffer));
    memcpy(buffer, &req, sizeof(req));
    if(!DeviceIoControl(h, IOCTL_MSR_READ, buffer, sizeof(req), buffer,
       sizeof(buffer), &n, NULL)) return FALSE;
    memcpy(value, buffer, sizeof(*value));
    return n>=sizeof(*value);
}

BOOL pcis_msrwrite(HANDLE h, DWORD msr, ULONGLONG value) {
    MSR_WRITE_REQUEST r;
    DWORD n = 0;
    r.Msr=msr, r.Value=value;
    return DeviceIoControl(h, IOCTL_MSR_WRITE, &r, sizeof(r), NULL, 0, &n, NULL);
}

BOOL pcis_barsize(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE bar, PCI_BAR_SIZE_RESULT *result) {
    BYTE buffer[sizeof(PCI_BAR_SIZE_RESULT)];
    PCI_BAR_SIZE_REQUEST req;
    DWORD n = 0;

    if(!result) return FALSE;
    req.Bus=bus, req.Device=dev, req.Function=fun, req.BarIndex=bar;
    ZeroMemory(buffer, sizeof(buffer));
    memcpy(buffer, &req, sizeof(req));
    if(!DeviceIoControl(h, IOCTL_PCI_BAR_SIZE, buffer, sizeof(req), buffer, sizeof(buffer), &n, NULL)) return FALSE;
    memcpy(result, buffer, sizeof(*result));
    return n>=sizeof(*result);
}

void pcis_printcpuid(const CPUID_RESULT *r) {
    printf("EAX=%08lX  EBX=%08lX  ECX=%08lX  EDX=%08lX\n",
           (unsigned long)r->Eax, (unsigned long)r->Ebx,
           (unsigned long)r->Ecx, (unsigned long)r->Edx);
}

void pcis_printcpufeatures(HANDLE h) {
    CPUID_RESULT r;
    DWORD maxBasic = 0, maxExt = 0;

    if(!pcis_cpuid(h, 0, &r)) {
        printf("CPUID(0)���ѡA���~=%lu\n", GetLastError());
        return;
    }
    maxBasic = r.Eax;
    printf("�̤jBasic CPUID Leaf: 0x%08lX\n", (unsigned long)maxBasic);
    printf("CPU Vendor: %c%c%c%c%c%c%c%c%c%c%c%c\n",
           (char)(r.Ebx&255), (char)((r.Ebx>>8)&255), (char)((r.Ebx>>16)&255),
           (char)((r.Ebx>>24)&255), (char)(r.Edx&255), (char)((r.Edx>>8)&255),
           (char)((r.Edx>>16)&255), (char)((r.Edx>>24)&255), (char)(r.Ecx&255),
           (char)((r.Ecx>>8)&255), (char)((r.Ecx>>16)&255), (char)((r.Ecx>>24)&255));
    if(pcis_cpuid(h, 0x80000000, &r)) {
        maxExt = r.Eax;
        printf("�̤jExtended CPUID Leaf: 0x%08lX\n", (unsigned long)maxExt);
    }
    if(maxBasic>=1 && pcis_cpuid(h, 1, &r)) {
        printf("Family/Model/Stepping: 0x%08lX\n", (unsigned long)r.Eax);
        printf("Feature ECX: %08lX\nFeature EDX: %08lX\n", (unsigned long)r.Ecx, (unsigned long)r.Edx);
        printf("SSE=%s  SSE2=%s  SSE3=%s  SSSE3=%s  SSE4.1=%s  SSE4.2=%s  AVX=%s  HTT=%s\n",
               (r.Edx&(1UL<<25)) ?"Yes":"No", (r.Edx&(1UL<<26)) ?"Yes":"No", (r.Ecx&1) ?"Yes":"No",
               (r.Ecx&(1UL<<9)) ?"Yes":"No", (r.Ecx&(1UL<<19)) ?"Yes":"No", (r.Ecx&(1UL<<20)) ?"Yes":"No",
               (r.Ecx&(1UL<<28)) ?"Yes":"No", (r.Edx&(1UL<<28)) ?"Yes":"No");
    }
    if(maxExt>=0x80000001 && pcis_cpuid(h, 0x80000001, &r))
        printf("Extended Feature ECX=%08lX  EDX=%08lX  RDTSCP=%s\n", (unsigned long)r.Ecx, (unsigned long)r.Edx, (r.Edx&(1UL<<27)) ?"Yes":"No");
    if(maxExt>=0x80000004) {
        char brand[49];
        CPUID_RESULT *q = (CPUID_RESULT*)brand;
        int i;

        for(i=0; i<3; i++)
            if(!pcis_cpuid(h, 0x80000002+i, q+i)) return;
            brand[48] = 0;
            printf("CPU Brand: %s\n", brand);
    }
}

void pcis_printpcidevice(const PCI_DEVICE_INFO *d) {
    unsigned i;
    printf("%02X:%02X.%u  Vendor=%04X  Device=%04X  Class=%02X:%02X:%02X  Header=%02X\n",
           d->Bus, d->Device, d->Function, d->VendorId, d->DeviceId,
           d->ClassCode, d->SubClass, d->ProgIf, d->HeaderType);
    for(i=0; i<PCI_MAX_BARS; i++)
        if(d->Bars[i].Valid)
            printf("  BAR%u:  Base=%016llX %s%s  Len=%lu\n", i, (unsigned long long)d->Bars[i].BaseAddress,
                   d->Bars[i].IsMemory ?"MEM":"I/O", d->Bars[i].Is64Bit ?" 64":"", (unsigned long)d->Bars[i].Length);
    for(i=0; i<d->CapabilityCount; i++)
        printf("  CAP[%u]: ID=%02X  Offset=%02X\n", i, d->Capabilities[i].CapabilityId, d->Capabilities[i].Offset);
}