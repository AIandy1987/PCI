/* ���Y�ɦW��:PciUser.h
   �{���]�p:PIN-HSIEN CHIANG

   PCIControlSys User Mode���}����x86/Win32 */
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <Windows.h>
#include <winioctl.h>
#include <stdint.h>

#define PCI_MAX_BARS 6
#define PCI_MAX_CAPABILITIES 32
#define PCI_MAX_SCAN_RESULTS 1024
#define PCI_CONFIG_ADDRESS 0xCF8
#define PCI_CONFIG_DATA 0xCFC
#define PCI_HEADER_TYPE_MASK 0x7F
#define PCI_HEADER_TYPE_DEVICE 0x00
#define PCI_HEADER_TYPE_BRIDGE 0x01
#define PCI_HEADER_TYPE_CARDBUS 0x02

#define IOCTL_PCI_READ8 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x900, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_READ16 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_READ32 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x902, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_WRITE8 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x903, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_WRITE16 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x904, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_WRITE32 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x905, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_SCAN CTL_CODE(FILE_DEVICE_UNKNOWN, 0x910, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_MSR_READ CTL_CODE(FILE_DEVICE_UNKNOWN, 0x920, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_MSR_WRITE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x921, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_CPUID CTL_CODE(FILE_DEVICE_UNKNOWN, 0x930, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_TSC CTL_CODE(FILE_DEVICE_UNKNOWN, 0x931, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_CPUID_EX CTL_CODE(FILE_DEVICE_UNKNOWN, 0x932, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_RDTSCP CTL_CODE(FILE_DEVICE_UNKNOWN, 0x933, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_CONTROL_REGS CTL_CODE(FILE_DEVICE_UNKNOWN, 0x934, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_BAR_SIZE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x940, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define PCIControlSys_DEVICE_PATH L"\\\\.\\PCIControlSys"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _PCI_BDF_REQUEST {
    BYTE Bus, Device, Function, Offset;
} PCI_BDF_REQUEST;

typedef struct _PCI_BDF_WRITE8_REQUEST {
    BYTE Bus, Device, Function, Offset, Value;
} PCI_BDF_WRITE8_REQUEST;

typedef struct _PCI_BDF_WRITE16_REQUEST {
    BYTE Bus, Device, Function, Offset;
    WORD Value;
} PCI_BDF_WRITE16_REQUEST;

typedef struct _PCI_BDF_WRITE32_REQUEST {
    BYTE Bus, Device, Function, Offset;
    DWORD Value;
} PCI_BDF_WRITE32_REQUEST;

typedef struct _MSR_REQUEST {
    DWORD Msr;
} MSR_REQUEST;

typedef struct _MSR_WRITE_REQUEST {
    DWORD Msr;
    ULONGLONG Value;
} MSR_WRITE_REQUEST;

typedef struct _CPUID_REQUEST {
    DWORD Leaf;
} CPUID_REQUEST;

typedef struct _CPUID_EX_REQUEST {
    DWORD Leaf, SubLeaf;
} CPUID_EX_REQUEST;

typedef struct _CPUID_RESULT {
    DWORD Eax, Ebx, Ecx, Edx;
} CPUID_RESULT;

typedef struct _TSC_AUX_RESULT {
    ULONGLONG Tsc;
    DWORD Aux;
} TSC_AUX_RESULT;

typedef struct _CPU_CONTROL_REGS_RESULT {
    DWORD Cr0, Cr2, Cr3, Cr4, Eflags;
} CPU_CONTROL_REGS_RESULT;

typedef struct _PCI_BAR_SIZE_REQUEST {
    BYTE Bus, Device, Function, BarIndex;
} PCI_BAR_SIZE_REQUEST;

typedef struct _PCI_BAR_SIZE_RESULT {
    ULONGLONG BaseAddress, Length;
    BYTE IsMemory, Is64Bit, Prefetchable, Valid;
} PCI_BAR_SIZE_RESULT;

typedef struct _PCI_CAPABILITY_INFO {
    BYTE CapabilityId, Offset, Reserved[2];
    WORD MsiMessageControl, MsixMessageControl;
    BYTE PcieVersion, PcieDeviceType;
    WORD PcieLinkStatus;
} PCI_CAPABILITY_INFO;

typedef struct _PCI_BAR_INFO {
    DWORD RawValueLow, RawValueHigh;
    ULONGLONG BaseAddress;
    DWORD Length;
    BYTE IsMemory, Is64Bit, Prefetchable, Valid;
} PCI_BAR_INFO;

typedef struct _PCI_DEVICE_INFO {
    BYTE Bus, Device, Function, HeaderType;
    WORD VendorId, DeviceId;
    BYTE RevisionId, ProgIf, SubClass, ClassCode;
    WORD SubsystemVendorId, SubsystemId;
    BYTE InterruptLine, InterruptPin, PrimaryBus, SecondaryBus, SubordinateBus;
    BYTE IsBridge, IsMultiFunction;
    DWORD Command, Status;
    PCI_BAR_INFO Bars[PCI_MAX_BARS];
    BYTE CapabilityCount;
    PCI_CAPABILITY_INFO Capabilities[PCI_MAX_CAPABILITIES];
} PCI_DEVICE_INFO;

typedef struct _PCI_SCAN_RESULT {
    DWORD DeviceCount;
    PCI_DEVICE_INFO Devices[PCI_MAX_SCAN_RESULTS];
} PCI_SCAN_RESULT;

/* User Mode�]�˨禡 */
HANDLE pcis_open(void);
void pcis_close(HANDLE hdevice);
BOOL pcis_pciread8(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, BYTE *value);
BOOL pcis_pciread16(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, WORD *value);
BOOL pcis_pciread32(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, DWORD *value);
BOOL pcis_pciwrite8(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, BYTE value);
BOOL pcis_pciwrite16(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, WORD value);
BOOL pcis_pciwrite32(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE off, DWORD value);
BOOL pcis_pciscan(HANDLE h, PCI_SCAN_RESULT *result);
BOOL pcis_cpuid(HANDLE h, DWORD leaf, CPUID_RESULT *result);
BOOL pcis_cpuidex(HANDLE h, DWORD leaf, DWORD subleaf, CPUID_RESULT *result);
BOOL pcis_rdtsc(HANDLE h, ULONGLONG *tsc);
BOOL pcis_rdtscp(HANDLE h, TSC_AUX_RESULT *result);
BOOL pcis_readcontrolregs(HANDLE h, CPU_CONTROL_REGS_RESULT *result);
BOOL pcis_msrread(HANDLE h, DWORD msr, ULONGLONG *value);
BOOL pcis_msrwrite(HANDLE h, DWORD msr, ULONGLONG value);
BOOL pcis_barsize(HANDLE h, BYTE bus, BYTE dev, BYTE fun, BYTE bar, PCI_BAR_SIZE_RESULT *result);
void pcis_printcpuid(const CPUID_RESULT *r);
void pcis_printcpufeatures(HANDLE h);
void pcis_printpcidevice(const PCI_DEVICE_INFO *d);

#ifdef __cplusplus
}
#endif