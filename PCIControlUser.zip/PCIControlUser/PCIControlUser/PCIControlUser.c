/* �{���M�צW��:PCIControlUser.c
   �{���]�p:PIN-HSIEN CHIANG */
#include "PciUser.h"
#include <stdio.h>
#include <stdlib.h>

static void wait_key(void) {
    printf("\n��<Enter>�~��...");
    getchar();
}

static unsigned read_hex(const char *p) {
    unsigned x = 0;
    printf("%s", p);
    scanf("%x", &x);
    while(getchar()!='\n');
    return x;
}

static void menu(void) {
    puts("\n================ PCIControlSys x86 User Mode ================");
    puts("1.  CPU Vendor / Feature / Brand");
    puts("2.  CPUID Leaf");
    puts("3.  CPUID Leaf + SubLeaf");
    puts("4.  RDTSC");
    puts("5.  RDTSCP + TSC_AUX");
    puts("6.  Ū��CR0/CR2/CR3/CR4/EFLAGS");
    puts("7.  PCI���챽�y");
    puts("8.  PCI Config Read 8/16/32");
    puts("9.  PCI Config Write 8/16/32");
    puts("10. PCI BAR Size Probe");
    puts("11. RDMSR");
    puts("12. WRMSR[�M�I:�u��VM/���祭�x]");
    puts("0.  ���}");
}

int main(int argc, char *argv[]) {
    HANDLE h = pcis_open();
    int choice;

    if(h==INVALID_HANDLE_VALUE) {
        printf("�L�k�}��\\\\.\\PCIControlSys, Win32  Error=%lu\n", GetLastError());
        return 1;
    }
    printf("PCIControlSys�w�s�u�C\n");
    for(;;) {
        menu();
        printf("���:");
        if(scanf("%d", &choice)!=1) {
            while(getchar()!='\n');
            continue;
        }
        while(getchar()!='\n');
        if(choice==0) break;
        if(choice==1) {
            pcis_printcpufeatures(h);
            wait_key();
        }
        else if(choice==2) {
            DWORD leaf = read_hex("Leaf (hex): ");
            CPUID_RESULT r;

            if(pcis_cpuid(h, leaf, &r)) pcis_printcpuid(&r);
            else printf("���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==3) {
            DWORD l=read_hex("Leaf (hex): "), s=read_hex("SubLeaf (hex): ");
            CPUID_RESULT r;

            if(pcis_cpuidex(h, l, s, &r)) pcis_printcpuid(&r);
            else printf("���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==4) {
            ULONGLONG t;

            if(pcis_rdtsc(h, &t)) printf("TSC=%016llX Error=%lu\n", GetLastError());
            else printf("RDTSC����, ���~�X=%lu\n", (unsigned long)GetLastError());
        }
        else if(choice==5) {
            TSC_AUX_RESULT r;

            if(pcis_rdtscp(h, &r)) printf("TSC=%016llX  AUX=%08lX\n", (unsigned long long)r.Tsc, (unsigned long)r.Aux);
            else printf("RDTSCP����, CPU/OS�i�ण�䴩�C Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==6) {
            CPU_CONTROL_REGS_RESULT r;

            if(pcis_readcontrolregs(h, &r)) printf("CR0=%08lX  CR2=%08lX  CR3=%08lX  CR4=%08lX  EFLAGS=%08lX\n",
                                                   (unsigned long)r.Cr0, (unsigned long)r.Cr2, (unsigned long)r.Cr3,
                                                   (unsigned long)r.Cr4, (unsigned long)r.Eflags);
            else printf("���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==7) {
            PCI_SCAN_RESULT *r = (PCI_SCAN_RESULT*)malloc(sizeof(PCI_SCAN_RESULT));
            DWORD i;

            if(!r){ puts("�O����t�m����"); continue; }
            if(pcis_pciscan(h, r)) {
                if(r->DeviceCount>PCI_MAX_SCAN_RESULTS) printf("���~:PCI�˸m�ƶq�W�X�}�C�e�q�C\n");
                else printf("PCI Device Count=%lu\n", (unsigned long)r->DeviceCount);
                for(i=0; i<r->DeviceCount; i++) pcis_printpcidevice(&r->Devices[i]);
            }
            else printf("PCI Scan���� Error=%lu\n", GetLastError());
            free(r);
            wait_key();
        }
        else if (choice==8) {
            unsigned b=read_hex("Bus: "), d=read_hex("Device: "),
                     f=read_hex("Function: "), o=read_hex("Offset: "),
                     w=read_hex("Width (8/16/32): ");

            if(w==8) {
                BYTE v;
                if(pcis_pciread8(h, b, d, f, o, &v)) printf("%02X\n", v);
                else printf("����\n");
            }
            else if(w==16) {
                WORD v;
                if(pcis_pciread16(h, b, d, f, o, &v)) printf("%04X\n", v);
                else printf("����\n");
            }
            else {
                DWORD v;
                if(pcis_pciread32(h, b, d, f, o, &v)) printf("%08lX\n", (unsigned long)v);
                else printf("����\n");
            }
            wait_key();
        }
        else if(choice==9) {
            unsigned b=read_hex("Bus: "), d=read_hex("Device: "),
                     f=read_hex("Function: "), o=read_hex("Offset: "),
                     w=read_hex("Width (8/16/32): "), v=read_hex("Value: ");
            BOOL ok = FALSE;

            if(w==8) ok = pcis_pciwrite8(h, b, d, f, o, (BYTE)v);
            else if(w==16) ok = pcis_pciwrite16(h, b, d, f, o, (WORD)v);
            else ok = pcis_pciwrite32(h, b, d, f, o, v);

            printf(ok ?"�g�J���\\n":"�g�J���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==10) {
            unsigned b=read_hex("Bus: "), d=read_hex("Device: "),
                     f=read_hex("Function: "), bar=read_hex("BAR index: ");
            PCI_BAR_SIZE_RESULT r;

            if(pcis_barsize(h, b, d, f, bar, &r))
                printf("Base=%016llX  Length=%016llX  Memory=%u  64Bit=%u  Prefetch=%u  Valid=%u\n",
                       (unsigned long long)r.BaseAddress, (unsigned long long)r.Length, r.IsMemory,
                       r.Is64Bit, r.Prefetchable, r.Valid);
            else printf("���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==11) {
            DWORD msr = read_hex("MSR index: ");
            ULONGLONG v;

            if(pcis_msrread(h, msr, &v))
                printf("MSR[%08lX]=%016llX\n", (unsigned long)msr, (unsigned long long)v);
            else printf("RDMSR���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else if(choice==12) {
            DWORD msr = read_hex("MSR index: ");
            unsigned long long v;

            printf("Value (64-bit hex): ");
            scanf("%llx", &v);
            while(getchar()!='\n');
            puts("ĵ�i:WRMSR���~�i��y���t�η����εw�骬�A���`�C");
            if(pcis_msrwrite(h, msr, (ULONGLONG)v)) puts("WRMSR���\");
            else printf("WRMSR���� Error=%lu\n", GetLastError());
            wait_key();
        }
        else puts("�����ﶵ");
    }
    pcis_close(h);
    return 0;
}