;=========================================================================
;�ɮצW��:PCIScan.asm
;�{���]�p:���~��
;
;Requires:
;  Intel 80386 or later
;  PCI BIOS / PCI Hardware
;  DOS 5.0+
;
;NASM����:PCI�˸m���y�A�C�XVendor ID / Device ID / Class Code��...
;�䴩16-bit DOS���ҡA�i�Ω�DOSBox-X����
;=========================================================================

;-------------------- ��Ķ���]�w --------------------
BITS 16
ORG 100h

jmp    start

;-------------------- ��ư� Data --------------------
section .data
      header_msg     db\
'BUS,DEV,FUNC,VENDOR,VENDORNAME,DEVICE,DEVICENAME,CLASS,CLASSNAME,\
SUBCLASS,SUBCLASSNAME,PROGIF,REV,HEADER,MULTIFUNC,IRQ,\
CMD,CAPPTR,STATUS,BAR0,BAR1,BAR2,BAR3,BAR4,BAR5,PCIE',13,10

      header_len     equ  $-header_msg

      header_print   db\
'BUS,DEV,FUNC,VENDOR,VENDORNAME,DEVICE,DEVICENAME,CLASS,CLASSNAME,\
SUBCLASS,SUBCLASSNAME,PROGIF,REV,HEADER,MULTIFUNC,IRQ,\
CMD,CAPPTR,STATUS,BAR0,BAR1,BAR2,BAR3,BAR4,BAR5,PCIE',13,10,'$'

      scan_msg           db   'Scanning Bus ','$'
      header_type        db      0
      is_multifunction   db      0
      irq_line           db      0
      command_reg        dw      0
      unused_msg         db   'Unused','$'
      pcie_version       db      0

      visited_caps times 256 db  0

      bar0_value         dd      0
      bar1_value         dd      0
      bar2_value         dd      0
      bar3_value         dd      0
      bar4_value         dd      0
      bar5_value         dd      0
      bar64_low          dd      0
      bar64_high         dd      0
      bar64hi_msg        db   '64HI','$'

      class_dword        dd      0
      filename           db   'PCI.txt',0
      filehandle         dw      0
      file_exists        db      0
      charbuf            db      0
      class_code         db      0
      sub_class          db      0
      prog_if            db      0
      rev_id             db      0
      vendor_id          dw      0
      device_id          dw      0
      cap_ptr            db      0
      pcie_found         db      0
      pcie_offset        db      0
      status_reg         dw      0

      class_unknown      db   'Unknown','$'
      class_00           db   'Unclassified','$'
      class_01           db   'Mass Storage','$'
      class_02           db   'Network Ctrl','$'
      class_03           db   'Display Ctrl','$'
      class_04           db   'Multimedia','$'
      class_05           db   'Memory Ctrl','$'
      class_06           db   'Bridge Dev','$'
      class_07           db   'Simple Comm','$'
      class_08           db   'Base System','$'
      class_09           db   'Input Device','$'
      class_0A           db   'Docking Station','$'
      class_0B           db   'Processor','$'
      class_0C           db   'Serial Bus','$'
      class_0D           db   'Communication Ctrl','$'
      class_0E           db   'System Peripheral','$'
      class_0F           db   'Wireless Ctrl','$'
      class_10           db   'Intelligent I/O','$'
      class_11           db   'Satellite Comm','$'
      class_12           db   'Encryption Ctrl','$'
      class_13           db   'Data Acquisition','$'
      class_14           db   'Non-Essential Instrumentation','$'

      sub_unknown        db   'Unknown','$'
      sc_0100            db   'SCSI Storage','$'
      sc_0101            db   'IDE Controller','$'
      sc_0106            db   'SATA Controller','$'
      sc_0200            db   'Ethernet Ctrl','$'
      sc_0201            db   'Token Ring','$'
      sc_0202            db   'FDDI Ctrl','$'
      sc_0300            db   'VGA Controller','$'
      sc_0301            db   'XGA Controller','$'
      sc_0600            db   'Host Bridge','$'
      sc_0601            db   'ISA Bridge','$'
      sc_0604            db   'PCI-PCI Bridge','$'

      ;Vendor�r���
      vendor_unknown     db   'Unknown','$'
      vendor_8086        db   'Intel','$'
      vendor_1022        db   'AMD','$'
      vendor_10DE        db   'NVIDIA','$'
      vendor_1234        db   'QEMU','$'
      vendor_1AF4        db   'VirtIO','$'
      vendor_104C        db   'Texas Instruments','$'
      vendor_10EC        db   'Realtek','$'
      vendor_14E4        db   'Broadcom','$'
      vendor_8087        db   'Intel Wireless','$'
      vendor_1002        db   'AMD GPU','$'
      vendor_1969        db   'Qualcomm Atheros','$'
      vendor_14C3        db   'MediaTek','$'
      vendor_1B21        db   'ASMedia','$'
      vendor_15AD        db   'VMware','$'
      vendor_1AB8        db   'Parallels','$'
      vendor_1D6A        db   'Xilinx','$'

      ;Device Name
      device_unknown     db   'Unknown Device','$'
      dev_8086_1237      db   '440FX Host Bridge','$'
      dev_8086_7000      db   'PIIX3 ISA Bridge','$'
      dev_8086_7010      db   'PIIX3 IDE Controller','$'
      dev_8086_7113      db   'PIIX4 Power Mgmt','$'
      dev_8086_2922      db   'ICH9 SATA Controller','$'
      dev_1234_1111      db   'QEMU VGA','$'
      dev_10DE_1C82      db   'GeForce GTX1050','$'
      dev_1AF4_1000      db   'VirtIO Network','$'
      dev_1AF4_1001      db   'VirtIO Block','$'

      cpu_msg            db   '386 or later CPU required.$'

section .text

;-------------------- �D�{�� Code --------------------
start:
      mov   ax,cs                  ;��l��DS/ES
      mov   ds,ax
      mov   es,ax
      call check_386               ;�ˬdCPU�O�_��386�H�W
      jc    cpu_error
      call open_or_create_file     ;�}�ҩΫإ߿�X��
      call print_header            ;���CSV���D�C
      xor   si,si                  ;Bus�q0�}�l bus = 0
      jmp   bus_loop
bus_loop:                          ;Bus���y
      xor   di,di                  ;Device�q0�}�l device = 0
      mov   ax,si                  ;��ܥثe���y����Bus
      call print_scan_bus
device_loop:                       ;Device���y
      xor   bp,bp                  ;Function�q0�}�l function = 0
function_loop:                     ;Function���y
      mov   byte [header_type],0   ;�M�������˸m��T
      mov   byte [pcie_found],0
      mov   byte [pcie_offset],0
      mov   byte [cap_ptr],0

      ;�إ�PCI CONFIG_ADDRESS
      mov   eax,80000000h
      movzx ecx,si    ;bus
      shl   ecx,16    ;bus<<16
      or    eax,ecx   ;�[�Jbus�줸
      movzx ecx,di    ;device
      shl   ecx,11    ;device<<11
      or    eax,ecx   ;�[�Jdevice�줸
      movzx ecx,bp    ;function
      shl   ecx,8     ;function<<8
      or    eax, ecx  ;�[�Jfunction�줸

      ;Ū��Vendor ID/Device ID
      mov   dx,0CF8h        ;Write CONFIG_ADDRESS
      out   dx,eax
      mov   dx,0CFCh        ;Read Vendor ID / Device ID
      in    eax,dx
      cmp   ax,0FFFFh       ;Vendor ID = FFFFh���ܤ��s�b
      je    next_function
      mov   dx,ax           ;���O�sVendor ID
      shr   eax,16          ;Device ID����AX
      mov   [vendor_id],dx
      mov   [device_id],ax  ;Save Vendor/Device DWORD

      ;Ū��Class Code
      mov   eax,80000008h   ;Read Class Code Revision (Offset 08h)
      movzx ecx,si          ;bus
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di          ;device
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp          ;function
      shl   ecx,8
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      mov   [class_dword],eax
      mov   [rev_id],al
      shr   eax,8
      mov   [prog_if],al
      shr   eax,8
      mov   [sub_class],al
      shr   eax,8
      mov   [class_code],al

      ;Ū��Header Type
      mov   eax,8000000Ch     ;Read Header Type (Offset = 0Eh)
      movzx ecx,si            ;Bus
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di            ;Device
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp            ;Function
      shl   ecx,8
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      shr   eax,16
      mov   ah,al
      and   al,7Fh            ;�u�O�dType
      mov   [header_type],al

      ;Multi-Function�P�_
      test  ah,80h                     ;Bit7=1���ܦh�\��˸m
      jz    .single
      mov   byte [is_multifunction],1
      jmp   .done
.single:
      mov   byte [is_multifunction],0  ;��\��˸m
.done:
      call read_irq           ;Ū��IRQ (Offset = 3Ch)
      call read_command       ;Ū��Command/Status Register (Offset = 04h)
      ;���yBAR0~BAR5
      mov   al,0              ;Base Address Register
      call read_bar
      mov   [bar0_value],eax
      mov   al,1
      call read_bar
      mov   [bar1_value],eax
      mov   al,2
      call read_bar
      mov   [bar2_value],eax
      mov   al,3
      call read_bar
      mov   [bar3_value],eax
      mov   al,4
      call read_bar
      mov   [bar4_value],eax
      mov   al,5
      call read_bar
      mov   [bar5_value],eax

      mov   byte [cap_ptr],0
      mov   ax,[status_reg]

      test  ax,0010h          ;1=�䴩Capability List
      jz    .skip_cap_ptr
      call read_cap_ptr
      mov   al,[cap_ptr]
      cmp   al,40h
      jb    .skip_caps
      cmp   al,0FCh
      ja    .skip_caps
.skip_cap_ptr:
      mov   ax,[status_reg]
      test  ax,0010h
      jz    .skip_caps
      call read_status
      test  ax,0010h
      jz    .skip_caps
      call read_cap_ptr
      mov   al,[cap_ptr]      ;Capability Pointer�X�k���ˬd
      cmp   al,40h
      jb    .skip_caps
      cmp   al,0FCh
      ja    .skip_caps
      and   al,0FCh
      mov   [cap_ptr],al
      call scan_capabilities
.skip_caps:
      ;�I�s��X�禡��ܸ˸m��T
      push  si
      push  di
      push  bp
      call print_csv_entry
      add   sp,6            ;�M��bus/device/function�Ѽ�
next_function:
      ;Multi-function�P�_
      ;�Y���Omulti-function
      ;�u���yfunction 0
      cmp   bp,0
      jne   continue_functions
      cmp   byte [is_multifunction],1
      je    continue_functions
      jmp   next_device
continue_functions:
      inc   bp
      cmp   bp,8
      jl    function_loop   ;�p�Gfunction < 8�~���ˬd�U�@��function
next_device:
      inc   di
      cmp   di,32
      jl    device_loop     ;�p�Gdevice < 32�~���ˬd�U�@��device
      inc   si
      cmp   si,256
      jl    bus_loop        ;�p�Gbus < 256�~���ˬd�U�@��bus
      jmp   exit_program
cpu_error:                  ;CPU Error���~�禡
      mov   dx,cpu_msg
      mov   ah,09h
      int   21h
      mov   ax,4C01h
      int   21h
file_error:                 ;File Error���~�禡
      mov   ax,4C01h
      int   21h
exit_program:               ;�����{��
      call close_file
      mov   ax,4C00h
      int   21h

;------------- System / Initialization Function �禡 -------------
check_386:             ;CPU�ˬd�O�_��386�H�W
      pushfd
      pop   eax
      mov   ecx,eax
      xor   eax,40000h    ;AC Flag Bit18
      push  eax
      popfd
      pushfd
      pop   eax
      xor   eax,ecx
      test  eax,40000h
      jz    .not386
      clc
      ret
.not386:
      stc
      ret

;-------------------- PCI Read Function �禡 --------------------
read_irq:
      mov   eax,8000003Ch
      movzx ecx,si
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp
      shl   ecx,8
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      mov   [irq_line],al
      ret

read_command:
      mov   eax,80000004h
      movzx ecx,si
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp
      shl   ecx,8
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      mov   [command_reg],ax
      shr   eax,16
      mov   [status_reg],ax
      ret

read_bar:                    ;AL=BAR�s��(0~5) | �^��EAX=BAR��
      push  bx
      mov   bl,al
      mov   eax,80000010h
      movzx ecx,si
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp
      shl   ecx,8
      or    eax,ecx
      movzx ecx,bl
      shl   ecx,2            ;BAR*4
      add   eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      pop   bx
      ret

read_status:
      mov   eax,80000004h
      movzx ecx,si
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp
      shl   ecx,8
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      shr   eax,16
      ret

read_cap_ptr:
      mov   eax,80000034h
      movzx ecx,si
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp
      shl   ecx,8
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      mov   [cap_ptr],al
      ret

scan_capabilities:               ;PCI Express Capability�j�M���y
      mov   byte [pcie_found],0
      push  di
      mov   di,visited_caps
      mov   cx,256               ;�̦h���y256��Capability
      xor   al,al
      rep   stosb
      pop   di
      mov   al,[cap_ptr]
      and   al,0FCh              ;DWORD���
.next_cap:
      movzx bx,al
      cmp   byte [visited_caps+bx],1
      je    .done
      mov   byte [visited_caps+bx],1
      dec   cx
      jz    .done
      mov   bl,al
      mov   eax,80000000h
      movzx ecx,si
      shl   ecx,16
      or    eax,ecx
      movzx ecx,di
      shl   ecx,11
      or    eax,ecx
      movzx ecx,bp
      shl   ecx,8
      or    eax,ecx
      movzx ecx,bl
      and   ecx,0FCh
      or    eax,ecx
      mov   dx,0CF8h
      out   dx,eax
      mov   dx,0CFCh
      in    eax,dx
      cmp   al,10h
      jne   .next
      mov   byte [pcie_found],1
      mov   [pcie_offset],bl
      jmp   .done
.next:
      cmp   ah,0
      je    .done
      cmp   ah,bl
      je    .done
      mov   al,ah                ;Next Capability Pointer
      jmp   .next_cap
.done:
      ret

;-------------------- Database Lookup �禡 --------------------
get_class_name:
      mov   al,[class_code]
      cmp   al,00h
      je    .c00
      cmp   al,01h
      je    .c01
      cmp   al,02h
      je    .c02
      cmp   al,03h
      je    .c03
      cmp   al,04h
      je    .c04
      cmp   al,05h
      je    .c05
      cmp   al,06h
      je    .c06
      cmp   al,07h
      je    .c07
      cmp   al,08h
      je    .c08
      cmp   al,09h
      je    .c09
      cmp   al,0Ah
      je    .c0A
      cmp   al,0Bh
      je    .c0B
      cmp   al,0Ch
      je    .c0C
      cmp   al,0Dh
      je    .c0D
      cmp   al,0Eh
      je    .c0E
      cmp   al,0Fh
      je    .c0F
      cmp   al,10h
      je    .c10
      cmp   al,11h
      je    .c11
      cmp   al,12h
      je    .c12
      cmp   al,13h
      je    .c13
      cmp   al,14h
      je    .c14
      mov   dx,class_unknown
      ret
.c00:
      mov   dx,class_00
      ret
.c01:
      mov   dx,class_01
      ret
.c02:
      mov   dx,class_02
      ret
.c03:
      mov   dx,class_03
      ret
.c04:
      mov   dx,class_04
      ret
.c05:
      mov   dx,class_05
      ret
.c06:
      mov   dx,class_06
      ret
.c07:
      mov   dx,class_07
      ret
.c08:
      mov   dx,class_08
      ret
.c09:
      mov   dx,class_09
      ret
.c0A:
      mov   dx,class_0A
      ret
.c0B:
      mov   dx,class_0B
      ret
.c0C:
      mov   dx,class_0C
      ret
.c0D:
      mov   dx,class_0D
      ret
.c0E:
      mov   dx,class_0E
      ret
.c0F:
      mov   dx,class_0F
      ret
.c10:
      mov   dx,class_10
      ret
.c11:
      mov   dx,class_11
      ret
.c12:
      mov   dx,class_12
      ret
.c13:
      mov   dx,class_13
      ret
.c14:
      mov   dx,class_14
      ret

get_vendor_name:
      mov   ax,[vendor_id]
      cmp   ax,8086h
      je    .intel
      cmp   ax,1022h
      je    .amd
      cmp   ax,10DEh
      je    .nvidia
      cmp   ax,1234h
      je    .qemu
      cmp   ax,1AF4h
      je    .virtio
      cmp   ax,104Ch
      je    .ti
      cmp   ax,10ECh
      je    .realtek
      cmp   ax,14E4h
      je    .broadcom
      cmp   ax,8087h
      je    .intel_wireless
      cmp   ax,1002h
      je    .amdgpu
      cmp   ax,1969h
      je    .atheros
      cmp   ax,14C3h
      je    .mediatek
      cmp   ax,1B21h
      je    .asmedia
      cmp   ax,15ADh
      je    .vmware
      cmp   ax,1AB8h
      je    .parallels
      cmp   ax,1D6Ah
      je    .xilinx
      mov   dx,vendor_unknown
      ret
.intel:
      mov   dx,vendor_8086
      ret
.amd:
      mov   dx,vendor_1022
      ret
.nvidia:
      mov   dx,vendor_10DE
      ret
.qemu:
      mov   dx,vendor_1234
      ret
.virtio:
      mov   dx,vendor_1AF4
      ret
.ti:
      mov   dx,vendor_104C
      ret
.realtek:
      mov   dx,vendor_10EC
      ret
.broadcom:
      mov   dx,vendor_14E4
      ret
.intel_wireless:
      mov   dx,vendor_8087
      ret
.amdgpu:
      mov   dx,vendor_1002
      ret
.atheros:
      mov   dx,vendor_1969
      ret
.mediatek:
      mov   dx,vendor_14C3
      ret
.asmedia:
      mov   dx,vendor_1B21
      ret
.vmware:
      mov   dx,vendor_15AD
      ret
.parallels:
      mov   dx,vendor_1AB8
      ret
.xilinx:
      mov   dx,vendor_1D6A
      ret

get_device_name:
      mov   ax,[vendor_id]
      cmp   ax,8086h
      je    .intel
      cmp   ax,1234h
      je    .qemu
      cmp   ax,10DEh
      je    .nvidia
      cmp   ax,1AF4h
      je    .virtio
      mov   dx,device_unknown
      ret
.intel:                       ;Intel
      mov   ax,[device_id]
      cmp   ax,1237h
      je    .i1237
      cmp   ax,7000h
      je    .i7000
      cmp   ax,7010h
      je    .i7010
      cmp   ax,7113h
      je    .i7113
      cmp   ax,2922h
      je    .i2922
      mov   dx,device_unknown
      ret
.i1237:
      mov   dx,dev_8086_1237
      ret
.i7000:
      mov   dx,dev_8086_7000
      ret
.i7010:
      mov   dx,dev_8086_7010
      ret
.i7113:
      mov   dx,dev_8086_7113
      ret
.i2922:
      mov   dx,dev_8086_2922
      ret
.qemu:                        ;QEMU
      mov   ax,[device_id]
      cmp   ax,1111h
      je    .qemu_vga
      mov   dx,device_unknown
      ret
.qemu_vga:
      mov   dx,dev_1234_1111
      ret
.nvidia:                      ;NVIDIA
      mov   ax,[device_id]
      cmp   ax,1C82h
      je    .gtx1050
      mov   dx,device_unknown
      ret
.gtx1050:
      mov   dx,dev_10DE_1C82
      ret
.virtio:                      ;VirtIO
      mov   ax,[device_id]
      cmp   ax,1000h
      je    .net
      cmp   ax,1001h
      je    .blk
      mov   dx,device_unknown
      ret
.net:
      mov   dx,dev_1AF4_1000
      ret
.blk:
      mov   dx,dev_1AF4_1001
      ret

get_subclass_name:
      mov   al,[class_code]
      cmp   al,01h
      je    .class01
      cmp   al,02h
      je    .class02
      cmp   al,03h
      je    .class03
      cmp   al,06h
      je    .class06
      mov   dx,sub_unknown
      ret
.class01:                    ;Mass Storage(Class 01)
      mov   al,[sub_class]
      cmp   al,00h
      je    .sc0100
      cmp   al,01h
      je    .sc0101
      cmp   al,06h
      je    .sc0106
      mov   dx,sub_unknown
      ret
.sc0100:
      mov   dx,sc_0100
      ret
.sc0101:
      mov   dx,sc_0101
      ret
.sc0106:
      mov   dx,sc_0106
      ret
.class02:                    ;Network(Class 02)
      mov   al,[sub_class]
      cmp   al,00h
      je    .sc0200
      cmp   al,01h
      je    .sc0201
      cmp   al,02h
      je    .sc0202
      mov   dx,sub_unknown
      ret
.sc0200:
      mov   dx,sc_0200
      ret
.sc0201:
      mov   dx,sc_0201
      ret
.sc0202:
      mov   dx,sc_0202
      ret
.class03:                    ;Display(Class 03)
      mov   al,[sub_class]
      cmp   al,00h
      je    .sc0300
      cmp   al,01h
      je    .sc0301
      mov   dx,sub_unknown
      ret
.sc0300:
      mov   dx,sc_0300
      ret
.sc0301:
      mov   dx,sc_0301
      ret
.class06:                    ;Bridge(Class 06)
      mov   al,[sub_class]
      cmp   al,00h
      je    .sc0600
      cmp   al,01h
      je    .sc0601
      cmp   al,04h
      je    .sc0604
      mov   dx,sub_unknown
      ret
.sc0600:
      mov   dx,sc_0600
      ret
.sc0601:
      mov   dx,sc_0601
      ret
.sc0604:
      mov   dx,sc_0604
      ret

;-------------------- Output Functions �禡 --------------------
print_csv_entry:             ;CSV��X�@��PCI�˸m��T
      push  bp
      mov   bp,sp
      mov   ax,[bp+8]        ;Bus
      call print_hex8
      call print_comma
      mov   ax,[bp+6]        ;Device
      call print_hex8
      call print_comma
      mov   ax,[bp+4]        ;Function
      call print_hex8
      call print_comma
      mov   ax,[vendor_id]   ;Vendor ID
      call print_hex16
      call print_comma
      mov   dl,'"'
      call print_char
      call get_vendor_name   ;Vendor Name
      call print_string
      mov   dl,'"'
      call print_char
      call print_comma
      mov   ax,[device_id]   ;Device ID
      call print_hex16
      call print_comma
      mov   dl,'"'
      call print_char
      call get_device_name   ;Device Name
      call print_string
      mov   dl,'"'
      call print_char
      call print_comma
      mov   al,[class_code]  ;Class Code
      call print_hex8
      call print_comma
      mov   dl,'"'
      call print_char
      call get_class_name    ;Class Name
      call print_string
      mov   dl,'"'
      call print_char
      call print_comma
      mov   al,[sub_class]   ;Subclass
      call print_hex8
      call print_comma
      mov   dl,'"'
      call print_char
      call get_subclass_name ;Subclass Name
      call print_string
      mov   dl,'"'
      call print_char
      call print_comma
      mov   eax,[prog_if]    ;ProgIF
      call print_hex8
      call print_comma
      mov   al,[rev_id]      ;Revision ID
      call print_hex8
      call print_comma
      mov   al,[header_type] ;Header Type
      call print_hex8
      call print_comma
      mov   al,[is_multifunction]
      cmp   al,0
      je    .single
      mov   dl,'Y'
      call print_char
      jmp   .mf_done
.single:
      mov   dl,'N'
      call print_char
.mf_done:
      call print_comma
      mov   al,[irq_line]
      cmp   al,0FFh
      jne   .show_irq
      mov   dl,'-'
      call print_char
      jmp   .irq_done
.show_irq:
      call print_hex8
.irq_done:
      call print_comma
      mov   ax,[command_reg]
      call print_hex16
      call print_comma
      mov   al,[cap_ptr]
      call print_hex8
      call print_comma
      mov   ax,[status_reg]
      call print_hex16
      call print_comma
;-------------------------------------------
      mov   eax,[bar0_value]    ;BAR0
      call bar_is_64
      jc    .bar0_is64
      mov   eax,[bar0_value]
      call print_bar
      jmp   .bar0_done
.bar0_is64:
      mov   eax,[bar0_value]
      mov   edx,[bar1_value]
      call print_hex64
.bar0_done:
      call print_comma
;-------------------------------------------
      mov   eax,[bar0_value]    ;BAR1
      call bar_is_64
      jc    .bar1_hi
      mov   eax,[bar1_value]
      call print_bar
      jmp   .bar1_done
.bar1_hi:
      mov   dx,bar64hi_msg
      call print_string
      jmp   .bar1_done
.bar1_done:
      call print_comma
;-------------------------------------------
      mov   eax,[bar2_value]    ;BAR2
      call bar_is_64
      jc    .bar2_is64
      mov   eax,[bar2_value]
      call print_bar
      jmp   .bar2_done
.bar2_is64:
      mov   eax,[bar2_value]
      mov   edx,[bar3_value]
      call print_hex64
.bar2_done:
      call print_comma
;-------------------------------------------
      mov   eax,[bar2_value]    ;BAR3
      call bar_is_64
      jc    .bar3_hi
      mov   eax,[bar3_value]
      call print_bar
      jmp   .bar3_done
.bar3_hi:
      mov   dx,bar64hi_msg
      call print_string
.bar3_done:
      call print_comma
;-------------------------------------------
      mov   eax,[bar4_value]    ;BAR4
      call bar_is_64
      jc    .bar4_is64
      mov   eax,[bar4_value]
      call print_bar
      jmp   .bar4_done
.bar4_is64:
      mov   eax,[bar4_value]
      mov   edx,[bar5_value]
      call print_hex64
.bar4_done:
      call print_comma
;-------------------------------------------
      mov   eax,[bar4_value]    ;BAR5
      call bar_is_64
      jc    .bar5_hi
      mov   eax,[bar5_value]
      call print_bar
      jmp   .bar5_done
.bar5_hi:
      mov   dx,bar64hi_msg
      call print_string
.bar5_done:
      call print_comma
;-------------------------------------------
      mov   al,[pcie_found]
      cmp   al,0
      je    .not_pcie
      mov   dl,'Y'
      call print_char
      jmp   .pcie_done
.not_pcie:
      mov   dl,'N'
      call print_char
.pcie_done:
      call newline
      mov   sp,bp
      pop   bp
      ret

print_header:
      mov   dx,header_print  ;�ù����
      mov   ah,09h
      int   21h
      mov   dx,header_msg    ;�g�J�ɮ�
      mov   cx,header_len    ;�r�����
      call write_file
      ret

print_bar:                   ;BAR�����P�_
      cmp   eax,0
      jne   .not_zero
      mov   dx,unused_msg
      call print_string
      ret
.not_zero:
      push  edx
      test  eax,1
      jnz   .io_bar
      mov   edx,eax
      and   edx,06h        ;BAR bits[2:1] = 10b => 64-bit BAR
      cmp   edx,04h
      jne   .normal
      call print_hex32
      mov   dl,'*'
      call print_char
      jmp   .done
.normal:
      call print_hex32
      jmp   .done
.io_bar:
      and   eax,0FFFFFFFCh
      call print_hex32
.done:
      pop   edx
      ret

bar_is_64:
      test  eax,1
      jnz   .no
      mov   edx,eax
      and   edx,06h
      cmp   edx,04h
      je    .yes
.no:
      clc
      ret
.yes:
      stc
      ret

print_scan_bus:
      push  ax
      mov   dx,scan_msg
      mov   ah,09h
      int   21h
      pop   ax
      call print_hex8
      call newline
      ret

;-------------------- Utility Functions �禡 --------------------
newline:
      mov   dl,13     ;�^���r��
      call print_char
      mov   dl,10     ;����r��
      call print_char
      ret

print_comma:
      mov   dl,','    ;�r���r��
      call print_char
      ret

print_char:
      mov   ah,02h          ;screen
      int   21h
      mov   [charbuf],dl    ;save char
      mov   ah,40h          ;write file
      mov   bx,[filehandle]
      mov   cx,1
      mov   dx,charbuf
      int   21h
      ret

print_string:
      push  si
      mov   si,dx
.next:
      mov   al,[si]
      cmp   al,'$'
      je    .done
      mov   dl,al
      call print_char
      inc   si
      jmp   .next
.done:
      pop   si
      ret

hex_digit:
      cmp   dl,10
      jl    .digit
      add   dl,'A'-10
      jmp   .output
.digit:
      add   dl,'0'
.output:
      call print_char
      ret

print_hex8:
      push  ax
      mov   ah,al
      shr   ah,4
      and   al,0Fh
      mov   dl,ah
      call hex_digit
      mov   dl,al
      call hex_digit
      pop   ax
      ret

print_hex16:
      push  ax
      push  bx
      mov   bx,ax
      mov   al,bh
      call print_hex8
      mov   al,bl
      call print_hex8
      pop   bx
      pop   ax
      ret

print_hex32:
      push  eax
      shr   eax,16
      call print_hex16
      pop   eax
      and   eax,0FFFFh
      call print_hex16
      ret

print_hex64:
      push  eax
      push  edx
      mov   eax,edx
      call print_hex32
      pop   edx
      pop   eax
      call print_hex32
      ret

;-------------------- File Functions �禡 --------------------
open_or_create_file:             ;�}�ҩΫإ��ɮ�
      mov   ah,3Dh               ;���ն}�ҬJ���ɮ�
      mov   al,02h               ;Read/Write
      mov   dx,filename
      int   21h
      jc    .create_new
      mov   [filehandle],ax      ;�}�Ҧ��\
      mov   byte [file_exists],1
      mov   bx,ax                ;�����ɧ�(Append)
      mov   ax,4202h
      xor   cx,cx
      xor   dx,dx
      int   21h
      call newline
      ret
.create_new:
      mov   ah,3Ch               ;�إ߷s�� Create File
      xor   cx,cx                ;normal attribute
      mov   dx,filename
      int   21h
      jc    file_error
      mov   [filehandle],ax
      mov   byte [file_exists],0
      ret

write_file:
      ;DS:DX = buffer
      ;CX    = size
      mov   ah,40h               ;�g�J��ƨ��ɮ�
      mov   bx,[filehandle]
      int   21h
      ret

close_file:
      mov   ah,3Eh               ;�����ɮ�
      mov   bx,[filehandle]
      int   21h
      ret