/* ��@�ɦW��:PCIManagerSys.c
   �{���]�p:PIN-HSIEN CHIANG

   x86 Windows Kernel Driver:PCI/CPU/MSR/BAR�\��h */
#include <ntddk.h>
#include "PCIManagerSys.h"
NTSTATUS getcpuid_ex(ULONG leaf, ULONG subleaf, PCPUID_RESULT result) {
    if(!result)
        return STATUS_INVALID_PARAMETER;

    get_cpuidexAsm(leaf, subleaf, &result->Eax, &result->Ebx, &result->Ecx, &result->Edx);

    return STATUS_SUCCESS;
}

NTSTATUS read_tsc_aux(PTSC_AUX_RESULT result) {
    ULONG low, high, aux;

    if(!result)
        return STATUS_INVALID_PARAMETER;

    __try {
        read_tscpAsm(&low, &high, &aux);
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return GetExceptionCode();
    }
    result->Tsc = ((ULONGLONG)high<<32) | low;
    result->Aux = aux;

    return STATUS_SUCCESS;
}

NTSTATUS read_cpu_control_regs(PCPU_CONTROL_REGS_RESULT result) {
    if(!result)
        return STATUS_INVALID_PARAMETER;

    read_control_regsAsm(&result->Cr0, &result->Cr2, &result->Cr3, &result->Cr4, &result->Eflags);

    return STATUS_SUCCESS;
}

/* CPU API
   CPUID:��MASM����CPUID�ñN���G�g�J���c */
NTSTATUS getcpuid(ULONG leaf, PCPUID_RESULT result) {
    if(!result) return STATUS_INVALID_PARAMETER;

    get_cpuidAsm(leaf, &result->Eax, &result->Ebx,
                 &result->Ecx, &result->Edx);

    return STATUS_SUCCESS;
}

ULONGLONG read_tsc(VOID) {
    return read_tscAsm();
}

/* PCI Configuration Address
   �إ�PCI Configuration Address:bit31 Enable + B/D/F/Offset */
static ULONG pci_make_config_address(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset) {
    return (1UL<<31) | ((ULONG)bus<<16) |
           ((ULONG)dev<<11) | ((ULONG)func<<8) |
           ((ULONG)offset&0xFC);
}

/* PCI 32-bitŪ�� */
ULONG pci_read32(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset) {
    if(dev>=PCI_MAX_DEVICE || func>=PCI_MAX_FUNCTION ||
       offset>0xFC || (offset&3))
        return 0xFFFFFFFFUL;

    out32Asm(PCI_CONFIG_ADDRESS, pci_make_config_address(bus, dev, func, offset));

    return in32Asm(PCI_CONFIG_DATA);
}

/* PCI 16-bitŪ�� */
USHORT pci_read16(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset) {
    ULONG value;
    ULONG shift;

    if(offset>0xFE || (offset&1)) return 0xFFFF;

    value = pci_read32(bus, dev, func, (UCHAR)offset&0xFC);

    if(value==0xFFFFFFFFUL) return 0xFFFF;

    shift = ((ULONG)(offset&0x02))*8;

    return (USHORT)((value>>shift)&0xFFFFUL);
}

/* PCI 8-bitŪ�� */
UCHAR pci_read8(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset) {
    ULONG value;

    value = pci_read32(bus, dev, func, (UCHAR)(offset&0xFC));

    if(value==0xFFFFFFFFUL) return 0xFF;

    return (UCHAR)((value>>(((ULONG)offset&3)*8))&0xFF);
}

/* PCI BAR Scanner
   ���yBAR:����I/O�B32-bit Memory�B64-bit Memory */
static VOID pci_scan_bars(UCHAR bus, UCHAR dev, UCHAR func, PPCI_DEVICE_INFO info) {
    ULONG i;
    ULONG count;
    UCHAR headertype;

    headertype = pci_read8(bus, dev, func, 0x0E);
    count = pci_get_bar_count(headertype);

    for(i=0; i<PCI_MAX_BARS; ++i) {
        RtlZeroMemory(&info->Bars[i], sizeof(info->Bars[i]));
    }
    for(i=0; i<count; ++i) {
        UCHAR offset = (UCHAR)(PCI_BAR0_OFFSET+i*4);
        ULONG low = pci_read32(bus, dev, func, offset);

        if(low==0 || low==0xFFFFFFFFUL) continue;

        info->Bars[i].RawValueLow = low;
        if(low&1) {
            info->Bars[i].IsMemory = 0;
            info->Bars[i].BaseAddress = low & ~0x3UL;
            info->Bars[i].Valid = 1;
        }
        else {
            info->Bars[i].IsMemory = 1;
            info->Bars[i].Prefetchable = (low&8) ? 1 : 0;

            if((low&6)==4 && i+1<count) {
                ULONG high = pci_read32(bus, dev, func, (UCHAR)(offset+4));
                info->Bars[i].Is64Bit = 1;
                info->Bars[i].RawValueHigh = high;
                info->Bars[i].BaseAddress = ((ULONGLONG)high<<32) | (ULONGLONG)(low & ~0xFUL);
                info->Bars[i].Valid = 1;
                ++i;
            }
            else {
                info->Bars[i].BaseAddress = low & ~0xFUL;
                info->Bars[i].Valid = 1;
            }
        }
    }
}

/* PCI Capability Scanner
   ���yPCI Capability�쵲 */
static VOID pci_scan_capabilities(UCHAR bus, UCHAR dev, UCHAR func, PPCI_DEVICE_INFO info) {
    USHORT status;
    UCHAR pointer;
    ULONG count = 0;
    UCHAR visited[64];

    RtlZeroMemory(visited, sizeof(visited));
    status = pci_read16(bus, dev, func, 0x06);

    if(status==0xFFFF || !(status&0x0010)) return;

    pointer = pci_read8(bus, dev, func, PCI_CAPABILITY_POINTER_OFFSET);
    pointer &= 0xFC;

    while(pointer>=0x40 && pointer<=0xFC && count<PCI_MAX_CAPABILITIES) {
        UCHAR id;
        UCHAR next;
        UCHAR index;
        PCI_CAPABILITY_INFO *cap;
        index = (UCHAR)(pointer>>2);

        if(visited[index]) break;

        visited[index] = 1;

        id = pci_read8(bus, dev, func, pointer);
        next = pci_read8(bus, dev, func, (UCHAR)(pointer+1));
        next &= 0xFC;

        if(id==0) break;

        cap = &info->Capabilities[count];
        RtlZeroMemory(cap, sizeof(*cap));
        cap->CapabilityId = id;
        cap->Offset = pointer;

        if(id==PCI_CAP_ID_MSI) {
            cap->MsiMessageControl = pci_read16(bus, dev, func, (UCHAR)(pointer+2));
        }
        else if(id==PCI_CAP_ID_MSIX) {
            cap->MsixMessageControl = pci_read16(bus, dev, func, (UCHAR)(pointer+2));
        }
        else if(id==PCI_CAP_ID_PCIE) {
            USHORT pcieCap = pci_read16(bus, dev, func, (UCHAR)(pointer+2));
            cap->PcieVersion = (UCHAR)(pcieCap&0x0F);
            cap->PcieDeviceType = (UCHAR)(pcieCap>>4)&0x0F;

            if((ULONG)pointer+0x13<=0xFF) {
                cap->PcieLinkStatus = pci_read16(bus, dev, func, (UCHAR)(pointer+0x12));
            }
        }
        ++count;

        if(next==0 || next==pointer || next<0x40 || next>0xFC) break;

        pointer = next;
    }
    info->CapabilityCount = (UCHAR)count;
}

/* PCI Device Scanner
   ���y��@BDF */
static BOOLEAN pci_scan_function(UCHAR bus, UCHAR dev, UCHAR func, PPCI_DEVICE_INFO info) {
    ULONG id;
	ULONG commandstatus;
    ULONG classreg;
    ULONG headerreg;
    ULONG interrupt;
    UCHAR headertype;

    RtlZeroMemory(info, sizeof(*info));
    id = pci_read32(bus, dev, func, 0x00);

    if((USHORT)(id&0xFFFF)==PCI_INVALID_VENDOR_ID) return FALSE;

    info->Bus = bus;
    info->Device = dev;
    info->Function = func;
    info->VendorId = (USHORT)(id&0xFFFF);
    info->DeviceId = (USHORT)(id>>16);
    commandstatus = pci_read32(bus, dev, func, 0x04);
    info->Command = commandstatus&0xFFFF;
    info->Status = commandstatus>>16;
    classreg = pci_read32(bus, dev, func, 0x08);
    info->RevisionId = (UCHAR)classreg;
    info->ProgIf = (UCHAR)(classreg>>8);
    info->SubClass = (UCHAR)(classreg>>16);
    info->ClassCode = (UCHAR)(classreg>>24);
    headerreg = pci_read32(bus, dev, func, 0x0C);
    headertype = (UCHAR)(headerreg>>16);
    info->HeaderType = headertype;

    if(headertype&PCI_HEADER_MULTI_FUNCTION) {
        info->IsMultiFunction = 1;
    }

    interrupt = pci_read32(bus, dev, func, 0x3C);
    info->InterruptLine = (UCHAR)interrupt;
    info->InterruptPin = (UCHAR)(interrupt>>8);

    if((headertype&PCI_HEADER_TYPE_MASK)==PCI_HEADER_TYPE_DEVICE) {
        ULONG subsystem = pci_read32(bus, dev, func, 0x2C);
        info->SubsystemVendorId = (USHORT)subsystem;
        info->SubsystemId = (USHORT)(subsystem>>16);
    }
    if((headertype&PCI_HEADER_TYPE_MASK)==PCI_HEADER_TYPE_BRIDGE) {
        ULONG buses = pci_read32(bus, dev, func, 0x18);
        info->IsBridge = 1;
        info->PrimaryBus = (UCHAR)buses;
        info->SecondaryBus = (UCHAR)(buses>>8);
        info->SubordinateBus = (UCHAR)(buses>>16);
    }

    pci_scan_bars(bus, dev, func, info);
    pci_scan_capabilities(bus, dev, func, info);

    return TRUE;
}

/* ���y�Ҧ�Bus/Device/Function */
NTSTATUS pci_scan_all(PPCI_SCAN_RESULT result, ULONG maxDevices, PULONG deviceCount) {
    ULONG bus;
    ULONG dev;
    ULONG func;
    ULONG count = 0;

    if(!result || !deviceCount) {
        return STATUS_INVALID_PARAMETER;
    }
    if(maxDevices>PCI_MAX_SCAN_RESULTS) {
        maxDevices = PCI_MAX_SCAN_RESULTS;
    }

    RtlZeroMemory(result, sizeof(*result));

    for(bus=0; bus<PCI_MAX_BUS; ++bus) {
        for(dev=0; dev<PCI_MAX_DEVICE; ++dev) {
            BOOLEAN multi = FALSE;

            if(count>=maxDevices) goto Complete;
            if(pci_scan_function((UCHAR)bus, (UCHAR)dev, 0, &result->Devices[count])) {
                multi = result->Devices[count].IsMultiFunction;
                ++count;
            }
            if(!multi) continue;
            for(func=1; func<PCI_MAX_FUNCTION; ++func) {
                if(count>=maxDevices) goto Complete;
                if(pci_scan_function((UCHAR)bus, (UCHAR)dev, (UCHAR)func, &result->Devices[count])) {
                    ++count;
                }
            }
        }
    }
Complete:

    result->DeviceCount = count;
    *deviceCount = count;

    return STATUS_SUCCESS;
}

/* PCI 32-bit�g�J */
NTSTATUS pci_write32(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset, ULONG value) {
    if(dev>=PCI_MAX_DEVICE || func>=PCI_MAX_FUNCTION || offset>0xFC || (offset&3))
        return STATUS_INVALID_PARAMETER;

    out32Asm(PCI_CONFIG_ADDRESS, pci_make_config_address(bus, dev, func, offset));
    out32Asm(PCI_CONFIG_DATA, value);

    return STATUS_SUCCESS;
}

/* PCI 16-bit Read-Modify-Write */
NTSTATUS pci_write16(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset, USHORT value) {
    ULONG aligned;
    ULONG oldvalue;
    ULONG newvalue;
    ULONG shift;
    ULONG mask;

    if(offset>0xFE || (offset&1))
        return STATUS_INVALID_PARAMETER;

    aligned = offset&0xFC;
    oldvalue = pci_read32(bus, dev, func, (UCHAR)aligned);

    if(oldvalue==0xFFFFFFFFUL)
        return STATUS_DEVICE_NOT_CONNECTED;

    shift = ((ULONG)(offset&2))*8;
    mask = 0xFFFFUL<<shift;
    newvalue = (oldvalue & ~mask) | ((ULONG)value<<shift);

    return pci_write32(bus, dev, func, (UCHAR)aligned, newvalue);
}

/* PCI 8-bit Read-Modify-Write */
NTSTATUS pci_write8(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset, UCHAR value) {
    ULONG aligned;
    ULONG oldvalue;
    ULONG newvalue;
    ULONG shift;
    ULONG mask;

    aligned = offset&0xFC;
    oldvalue = pci_read32(bus, dev, func, (UCHAR)aligned);

    if(oldvalue==0xFFFFFFFFUL)
        return STATUS_DEVICE_NOT_CONNECTED;

    shift = ((ULONG)(offset&3))*8;
    mask = 0xFFUL<<shift;
    newvalue = (oldvalue & ~mask) | ((ULONG)value<<shift);

    return pci_write32(bus, dev, func, (UCHAR)aligned, newvalue);
}

/* RDMSR/WRMSR may generate a processor exception
   for an unsupported/inaccessible MSR.
   SEH converts that exception into an NTSTATUS.
   RDMSR�ϥ�SEH�קK�L��MSR�����y�����B�z�ҥ~ */
NTSTATUS read_msr_safe(ULONG msr, PULONGLONG value) {
    if(!value) return STATUS_INVALID_PARAMETER;

    __try {
        *value = read_msrAsm(msr);
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return GetExceptionCode();
    }

    return STATUS_SUCCESS;
}

NTSTATUS write_msr_safe(ULONG msr, ULONGLONG valuelow, ULONGLONG valuehigh) {
    ULONG low;
    ULONG high;

    low = (ULONG)(valuelow&0xFFFFFFFFUL);
    high = (ULONG)(valuehigh>>32);

    __try {
        write_msrAsm(msr, low, high);
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return GetExceptionCode();
    }

    return STATUS_SUCCESS;
}

/* Physical Memory Mapping
   �ϥ�MmMapIoSpace�M�g�w������} */
PVOID map_physical(ULONGLONG physicaladdress, SIZE_T size) {
    PHYSICAL_ADDRESS address;

    if(size==0) return NULL;

    address.QuadPart = (LONGLONG)physicaladdress;

    return MmMapIoSpace(address, size, MmNonCached);
}

/* Physical Memory Unmapping
   �Ѱ�MmMapIoSpace�إߪ��M�g */
VOID unmap_physical(PVOID baseaddress, SIZE_T size) {
    if(baseaddress==NULL) return;
    if(size==0) return;

    MmUnmapIoSpace(baseaddress, size);
}

/* ��PCI Header Type�M�wBAR�ƶq */
static ULONG pci_get_bar_count(UCHAR headerType) {
    switch(headerType&PCI_HEADER_TYPE_MASK) {
        case PCI_HEADER_TYPE_DEVICE:
            return 6;
        case PCI_HEADER_TYPE_BRIDGE:
            return 2;
        case PCI_HEADER_TYPE_CARDBUS:
            return 1;
        default:
            return 0;
    }
}

/* BAR Size Probe:�Ȯɰ���I/O /Memory Decode�g�J��1���oSize Mask */
static NTSTATUS pci_get_bar_info(UCHAR bus, UCHAR dev, UCHAR func, UCHAR barIndex, PPCI_BAR_SIZE_RESULT result) {
    UCHAR headertype;
    ULONG barcount;
    ULONG rawlow;
    ULONG rawhigh = 0;
    ULONG sizelow;
    ULONG sizehigh = 0;
    UCHAR offset;
    USHORT command;
    USHORT newcommand;
    ULONGLONG base;
    ULONGLONG length;

    if(!result || barIndex>=PCI_MAX_BARS)
        return STATUS_INVALID_PARAMETER;

    RtlZeroMemory(result, sizeof(*result));
    headertype = pci_read8(bus, dev, func, 0x0E);

    if(headertype==0xFF)
        return STATUS_DEVICE_NOT_CONNECTED;

    barcount = pci_get_bar_count(headertype);

    if(barIndex>=barcount)
        return STATUS_INVALID_PARAMETER;

    offset = (UCHAR)(PCI_BAR0_OFFSET+barIndex*4);
    rawlow = pci_read32(bus, dev, func, offset);

    if(rawlow==0xFFFFFFFFUL || rawlow==0)
        return STATUS_OBJECT_NAME_NOT_FOUND;

    result->IsMemory = (rawlow&1) ? 0 : 1;

    if(result->IsMemory) {
        result->Is64Bit = ((rawlow&0x06)==0x04);
        result->Prefetchable = (rawlow&0x08) ? 1 : 0;
    }

    /* BAR size probing changes
       PCI configuration registers.
       Temporarily disable IO/MEM decoding
       while probing, then restore
       every original value. */
    command = pci_read16(bus, dev, func, 0x04);

    if(command==0xFFFF)
        return STATUS_DEVICE_NOT_CONNECTED;

    newcommand = (USHORT)(command & ~(PCI_COMMAND_IO_ENABLE | PCI_COMMAND_MEMORY_ENABLE));

    if(!NT_SUCCESS(pci_write16(bus, dev, func, 0x04, newcommand)))
        return STATUS_UNSUCCESSFUL;

    if(result->IsMemory) {
        pci_write32(bus, dev, func, offset, 0xFFFFFFFFUL);
        sizelow = pci_read32(bus, dev, func, offset);

        if(result->Is64Bit && ((ULONG)barIndex+1UL)<barcount) {
            rawhigh = pci_read32(bus, dev, func, (UCHAR)(offset+4));
            pci_write32(bus, dev, func, (UCHAR)(offset+4), 0xFFFFFFFFUL);
            sizehigh = pci_read32(bus, dev, func, (UCHAR)(offset+4));
        }

        pci_write32(bus, dev, func, offset, rawlow);

        if(result->Is64Bit && ((ULONG)barIndex+1UL)<barcount) {
            pci_write32(bus, dev, func, (UCHAR)(offset+4), rawhigh);
        }

        base = (ULONGLONG)(rawlow & ~0xFUL);

        if(result->Is64Bit)
            base |= ((ULONGLONG)rawhigh<<32);
        if(result->Is64Bit) {
            ULONGLONG mask = ((ULONGLONG)sizehigh<<32) | (ULONGLONG)(sizelow & ~0xFUL);

            if(mask) length = (~mask)+1;
            else length = 0;
        }
        else {
            ULONG mask = sizelow & ~0xFUL;
            length = mask ? (ULONGLONG)(~mask+1UL) : 0;
        }
    }
    else {
        pci_write32(bus, dev, func, offset, 0xFFFFFFFFUL);
        sizelow = pci_read32(bus, dev, func, offset);
        pci_write32(bus, dev, func, offset, rawlow);
        base = (ULONGLONG)(rawlow & ~0x3UL);
        ULONG mask = sizelow & ~0x3UL;
        length = mask ? (ULONGLONG)(~mask+1UL) : 0;
    }

    pci_write16(bus, dev, func, 0x04, command);
    result->BaseAddress = base;
    result->Length = length;
    result->Valid = (length!=0) ? 1 : 0;

    return STATUS_SUCCESS;
}

/* ��~����BAR Size Probe API */
NTSTATUS pci_probe_bar_size(UCHAR bus, UCHAR dev, UCHAR func, UCHAR barIndex, PPCI_BAR_SIZE_RESULT result) {
    return pci_get_bar_info(bus, dev, func, barIndex, result);
}