/* �{���M�צW��:PCIControlSys.c
   �{���]�p:PIN-HSIEN CHIANG

   x86 Windows Kernel Driver:IRP/IOCTL����h */
#include <ntddk.h>
#include "PCIManagerSys.h"

/* CompleteIrp:�Τ@�]�wIRP���A�ç���IRP */
static NTSTATUS CompleteIrp(PIRP irp, NTSTATUS status, ULONG_PTR information) {
    if(irp==NULL) return status;

    irp->IoStatus.Status = status;
    irp->IoStatus.Information = information;
    IoCompleteRequest(irp, IO_NO_INCREMENT);

    return status;
}

/* Forward Declaration
   Driver�PIRP Dispatch�禡�ŧi */
DRIVER_UNLOAD DriverUnload;
DRIVER_DISPATCH DriverCreateClose;
DRIVER_DISPATCH DeviceControl;

/* CREATE / CLOSE:�B�zDevice�}�һP���� */
NTSTATUS DriverCreateClose(PDEVICE_OBJECT deviceobject, PIRP irp) {
    UNREFERENCED_PARAMETER(deviceobject);

    if(!irp) return STATUS_INVALID_PARAMETER;

    irp->IoStatus.Status = STATUS_SUCCESS;
    irp->IoStatus.Information = 0;
    IoCompleteRequest(irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

/* DEVICE_CONTROL:��IOCTL����PCI/MSR/CPU�ާ@ */
NTSTATUS DeviceControl(PDEVICE_OBJECT deviceobject, PIRP irp) {
    PIO_STACK_LOCATION stack;
    ULONG code;
    ULONG inlen;
    ULONG outlen;
    PVOID buffer;
    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;

    UNREFERENCED_PARAMETER(deviceobject);

    if(!irp) return STATUS_INVALID_PARAMETER;

    stack = IoGetCurrentIrpStackLocation(irp);

    if(!stack) return CompleteIrp(irp, STATUS_INVALID_PARAMETER, 0);

    code = stack->Parameters.DeviceIoControl.IoControlCode;
    inlen = stack->Parameters.DeviceIoControl.InputBufferLength;
    outlen = stack->Parameters.DeviceIoControl.OutputBufferLength;
    buffer = irp->AssociatedIrp.SystemBuffer;

    if(!buffer) return CompleteIrp(irp, STATUS_INVALID_PARAMETER, 0);
    switch(code) {
        case IOCTL_PCI_READ8:
            if(inlen<sizeof(PCI_BDF_REQUEST) || outlen<sizeof(UCHAR)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BDF_REQUEST r = (PPCI_BDF_REQUEST)buffer;
                *(UCHAR*)buffer = pci_read8(r->Bus, r->Device, r->Function, r->Offset);
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(UCHAR));
            }
        case IOCTL_PCI_READ16:
            if(inlen<sizeof(PCI_BDF_REQUEST) || outlen<sizeof(USHORT)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BDF_REQUEST r = (PPCI_BDF_REQUEST)buffer;
                *(USHORT*)buffer = pci_read16(r->Bus, r->Device, r->Function, r->Offset);
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(USHORT));
            }
        case IOCTL_PCI_READ32:
            if(inlen<sizeof(PCI_BDF_REQUEST) || outlen<sizeof(ULONG)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BDF_REQUEST r = (PPCI_BDF_REQUEST)buffer;
                *(ULONG*)buffer = pci_read32(r->Bus, r->Device, r->Function, r->Offset);
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(ULONG));
            }
        case IOCTL_PCI_WRITE8:
            if(inlen<sizeof(PCI_BDF_WRITE8_REQUEST)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BDF_WRITE8_REQUEST r = (PPCI_BDF_WRITE8_REQUEST)buffer;
                status = pci_write8(r->Bus, r->Device, r->Function, r->Offset, r->Value);
                return CompleteIrp(irp, status, 0);
            }
        case IOCTL_PCI_WRITE16:
            if(inlen<sizeof(PCI_BDF_WRITE16_REQUEST)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BDF_WRITE16_REQUEST r = (PPCI_BDF_WRITE16_REQUEST)buffer;
                status = pci_write16(r->Bus, r->Device, r->Function, r->Offset, r->Value);
                return CompleteIrp(irp, status, 0);
            }
        case IOCTL_PCI_WRITE32:
            if(inlen<sizeof(PCI_BDF_WRITE32_REQUEST)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BDF_WRITE32_REQUEST r = (PPCI_BDF_WRITE32_REQUEST)buffer;
                status = pci_write32(r->Bus, r->Device, r->Function, r->Offset, r->Value);
                return CompleteIrp(irp, status, 0);
            }
        case IOCTL_PCI_SCAN:
            if(outlen<sizeof(PCI_SCAN_RESULT)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, sizeof(PCI_SCAN_RESULT));
            }
            {
                ULONG count = 0;
                status = pci_scan_all((PPCI_SCAN_RESULT)buffer, PCI_MAX_SCAN_RESULTS, &count);

                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);

                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(ULONG)+count*sizeof(PCI_DEVICE_INFO));
            }
        case IOCTL_MSR_READ:
            if(inlen<sizeof(MSR_REQUEST) || outlen<sizeof(ULONGLONG)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PMSR_REQUEST r = (PMSR_REQUEST)buffer;
                ULONGLONG value = 0;
                status = read_msr_safe(r->Msr, &value);
                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);
                *(ULONGLONG*)buffer = value;
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(ULONGLONG));
            }
        case IOCTL_MSR_WRITE:
            if(inlen<sizeof(MSR_WRITE_REQUEST)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PMSR_WRITE_REQUEST r = (PMSR_WRITE_REQUEST)buffer;
                status = write_msr_safe(r->Msr, r->ValueLow, r->ValueHigh);
                return CompleteIrp(irp, status, 0);
            }
        case IOCTL_CPU_CPUID:
            if(inlen<sizeof(CPUID_REQUEST) || outlen<sizeof(CPUID_RESULT)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PCPUID_REQUEST r = (PCPUID_REQUEST)buffer;
                CPUID_RESULT result;
                status = getcpuid(r->Leaf, &result);
                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);
                RtlCopyMemory(buffer, &result, sizeof(result));
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(result));
            }
        case IOCTL_CPU_CPUID_EX:
            if(inlen<sizeof(CPUID_EX_REQUEST) || (outlen<sizeof(CPUID_RESULT))) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PCPUID_EX_REQUEST r = (PCPUID_EX_REQUEST)buffer;
                CPUID_RESULT result;
                status = getcpuid_ex(r->Leaf, r->SubLeaf, &result);
                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);
                RtlCopyMemory(buffer, &result, sizeof(result));
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(result));
            }
        case IOCTL_CPU_RDTSCP:
            if(outlen<sizeof(TSC_AUX_RESULT)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                TSC_AUX_RESULT result;
                status = read_tsc_aux(&result);
                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);
                RtlCopyMemory(buffer, &result, sizeof(result));
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(result));
            }
        case IOCTL_CPU_CONTROL_REGS:
            if(outlen<sizeof(CPU_CONTROL_REGS_RESULT)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                CPU_CONTROL_REGS_RESULT result;
                status = read_cpu_control_regs(&result);
                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);
                RtlCopyMemory(buffer, &result, sizeof(result));
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(result));
            }
        case IOCTL_CPU_TSC:
            if(outlen<sizeof(ULONGLONG)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            *(ULONGLONG*)buffer = read_tsc();
            return CompleteIrp(irp, STATUS_SUCCESS, sizeof(ULONGLONG));
        case IOCTL_PCI_BAR_SIZE:
            if(inlen<sizeof(PCI_BAR_SIZE_REQUEST) || outlen<sizeof(PCI_BAR_SIZE_RESULT)) {
                return CompleteIrp(irp, STATUS_BUFFER_TOO_SMALL, 0);
            }
            {
                PPCI_BAR_SIZE_REQUEST r = (PPCI_BAR_SIZE_REQUEST)buffer;
                PCI_BAR_SIZE_RESULT result;
                status = pci_probe_bar_size(r->Bus, r->Device, r->Function, r->BarIndex, &result);
                if(!NT_SUCCESS(status))
                    return CompleteIrp(irp, status, 0);
                RtlCopyMemory(buffer, &result, sizeof(result));
                return CompleteIrp(irp, STATUS_SUCCESS, sizeof(result));
            }
        default:
            status = STATUS_INVALID_DEVICE_REQUEST;
            break;
    }
    return CompleteIrp(irp, status, 0);
}

/* DriverUnload:�R��DOS Symbolic Link�PDevice Object */
VOID DriverUnload(PDRIVER_OBJECT driverobject) {
    UNICODE_STRING dosname;

    if(!driverobject) return;

    DbgPrint("PCIControlSys : �X�ʤw�����C\n");
    RtlInitUnicodeString(&dosname, COREDRIVER_DOS_NAME);
    IoDeleteSymbolicLink(&dosname);

    if(driverobject->DeviceObject!=NULL) {
        IoDeleteDevice(driverobject->DeviceObject);
    }
}

/* DriverEntry:�إ�Device Object�BSymbolic Link�PIRP Dispatch */
NTSTATUS DriverEntry(PDRIVER_OBJECT driverobject, PUNICODE_STRING registrypath) {
    NTSTATUS status;
    UNICODE_STRING devicename;
    UNICODE_STRING dosdevicename;
    PDEVICE_OBJECT deviceobject = NULL;

    UNREFERENCED_PARAMETER(registrypath);

    if(!driverobject) return STATUS_INVALID_PARAMETER;

    DbgPrint("PCIControlSys : �X�ʤw���J�C\n");
    RtlInitUnicodeString(&devicename, COREDRIVER_DEVICE_NAME);
    RtlInitUnicodeString(&dosdevicename, COREDRIVER_DOS_NAME);
    status = IoCreateDevice(driverobject, 0, &devicename,
                            FILE_DEVICE_UNKNOWN, 0, FALSE,
                            &deviceobject);

    if(!NT_SUCCESS(status)) {
        DbgPrint("PCIControlSys : IoCreateDevice���� : 0x%08X\n", status);

        return status;
    }

    status = IoCreateSymbolicLink(&dosdevicename, &devicename);

    if(!NT_SUCCESS(status)) {
        DbgPrint("PCIControlSys : IoCreateSymbolicLink���� : 0x%08X\n", status);
        IoDeleteDevice(deviceobject);

        return status;
    }

    driverobject->DriverUnload = DriverUnload;
    driverobject->MajorFunction[IRP_MJ_CREATE] = DriverCreateClose;
    driverobject->MajorFunction[IRP_MJ_CLOSE] = DriverCreateClose;
    driverobject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DeviceControl;
    deviceobject->Flags &= ~DO_DEVICE_INITIALIZING;
    DbgPrint("PCIControlSys : ��l�Ʀ��\�C\n");

    return STATUS_SUCCESS;
}