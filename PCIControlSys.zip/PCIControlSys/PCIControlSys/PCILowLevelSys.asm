;MASM, x86 Assembly�ɮצW��:PCILowLevelSys.asm
;�{���]�p:PIN-HSIEN CHIANG
;
;x86 MASM / __stdcall
;�\��:RDTSC�BCPUID�BI/O Port IN/OUT�BRDMSR / WRMSR
;
.686P
.MODEL FLAT, STDCALL
.CODE

;I/O Port API
;ULONGLONG __stdcall read_tscAsm(VOID)
;RDTSC: EDX:EAX=Time Stamp Counter
;Ū��CPU Time Stamp Counter ���G���EDX:EAX
PUBLIC read_tscAsm
read_tscAsm PROC
    rdtsc
    ret
read_tscAsm ENDP

;VOID __stdcall get_cpuidAsm(ULONG leaf, ULONG* eaxout,
;                            ULONG* ebxout, ULONG* ecxout, ULONG* edxout)
;5��DWORD: 5*4=20 bytes
;__stdcall: callee�M��stack
;����CPUID�N�|�ӼȦs�����G�g�J�I�s�ݴ��Ѫ�DWORD����
PUBLIC get_cpuidAsm
get_cpuidAsm PROC leaf:DWORD, eaxout:DWORD, ebxout:DWORD, ecxout:DWORD, edxout:DWORD
    ;EBX/ESI/EDI�����O�s
    push   ebx
    push   esi
    push   edi
    mov    eax,leaf
    cpuid
    mov    esi,eaxout           ;EAX
    mov    DWORD PTR [esi],eax
    mov    edi,ebxout           ;EBX
    mov    DWORD PTR [edi],ebx
    mov    esi,ecxout           ;ECX
    mov    DWORD PTR [esi],ecx
    mov    edi,edxout           ;EDX
    mov    DWORD PTR [edi],edx
    pop    edi
    pop    esi
    pop    ebx
    ret    20
get_cpuidAsm ENDP

;VOID __stdcall get_cpuidexAsm(ULONG leaf, ULONG subleaf, ULONG* eaxout,
;                              ULONG* ebxout, ULONG* ecxout, ULONG* edxout)
;CPUID��EAX=Leaf�BECX=SubLeaf
PUBLIC get_cpuidexAsm
get_cpuidexAsm PROC leaf:DWORD, subleaf:DWORD, eaxout:DWORD, ebxout:DWORD, ecxout:DWORD, edxout:DWORD
    push    ebx
    push    esi
    push    edi
    mov     eax,leaf
    mov     ecx,subleaf
    cpuid
    mov     esi,eaxout
    mov     DWORD PTR [esi],eax
    mov     edi,ebxout
    mov     DWORD PTR [edi],ebx
    mov     esi,ecxout
    mov     DWORD PTR [esi],ecx
    mov     edi,edxout
    mov     DWORD PTR [edi],edx
    pop     edi
    pop     esi
    pop     ebx
    ret     24
get_cpuidexAsm ENDP

;VOID __stdcall read_tscpAsm(ULONG* low, ULONG* high, ULONG* aux)
;RDTSCP�^��EDX:EAX=TSC�BECX=TSC_AUX
PUBLIC read_tscpAsm
read_tscpAsm PROC lowout:DWORD, highout:DWORD, auxout:DWORD
    push    edi
    rdtscp
    push    eax
    push    edx
    push    ecx
    mov     edi,lowout
    pop     eax
    mov     DWORD PTR [edi],eax
    pop     eax
    mov     edi,highout
    mov     DWORD PTR [edi],eax
    mov     edi,auxout
    pop     eax
    mov     DWORD PTR [edi],eax
    pop     edi
    ret     12
read_tscpAsm ENDP

;Ū���ثeCPU��x86����Ȧs��
PUBLIC read_control_regsAsm
read_control_regsAsm PROC cr0out:DWORD, cr2out:DWORD, cr3out:DWORD, cr4out:DWORD, eflagsout:DWORD
    push    edi
    push    eax
    pushfd
    pop     eax
    mov     edi,eflagsout
    mov     DWORD PTR [edi],eax
    mov     eax,cr0
    mov     edi,cr0out
    mov     DWORD PTR [edi],eax
    mov     eax,cr2
    mov     edi,cr2out
    mov     DWORD PTR [edi],eax
    mov     eax,cr3
    mov     edi,cr3out
    mov     DWORD PTR [edi],eax
    mov     eax,cr4
    mov     edi,cr4out
    mov     DWORD PTR [edi],eax
    pop     eax
    pop     edi
    ret     20
read_control_regsAsm ENDP

;UCHAR __stdcall in8Asm(USHORT port)
;�qI/O PortŪ��8�줸���
PUBLIC in8Asm
in8Asm PROC port:DWORD
    mov    dx,WORD PTR port
    in     al,dx
    ret    4
in8Asm ENDP

;USHORT __stdcall in16Asm(USHORT port)
;�qI/O PortŪ��16�줸���
PUBLIC in16Asm
in16Asm PROC port:DWORD
    mov    dx,WORD PTR port
    in     ax,dx
    ret    4
in16Asm ENDP

;ULONG __stdcall in32Asm(USHORT port)
;�qI/O PortŪ��32�줸���
PUBLIC in32Asm
in32Asm PROC port:DWORD
    mov    dx,WORD PTR port
    in     eax,dx
    ret    4
in32Asm ENDP

;VOID __stdcall out8Asm(USHORT port, UCHAR value)
;�VI/O Port�g�J8�줸���
PUBLIC out8Asm
out8Asm PROC port:DWORD, value:DWORD
    mov    dx,WORD PTR port
    mov    al,BYTE PTR value
    out    dx,al
    ret    8
out8Asm ENDP

;VOID __stdcall out16Asm(USHORT port, USHORT value)
;�VI/O Port�g�J16�줸���
PUBLIC out16Asm
out16Asm PROC port:DWORD, value:DWORD
    mov    dx,WORD PTR port
    mov    ax,WORD PTR value
    out    dx,ax
    ret    8
out16Asm ENDP

;VOID __stdcall _out32Asm(USHORT port, ULONG value)
;�VI/O Port�g�J32�줸���
PUBLIC out32Asm
out32Asm PROC port:DWORD, value:DWORD
    mov    dx,WORD PTR port
    mov    eax,value
    out    dx,eax
    ret    8
out32Asm ENDP

;ULONGLONG __stdcall read_msrAsm(ULONG msr)
;ECX=MSR index | EDX:EAX=MSR value
;Ū��MSR:ECX=MSR Index�^�ǭȬ�EDX:EAX
PUBLIC read_msrAsm
read_msrAsm PROC msr:DWORD
    mov    ecx,msr
    rdmsr
    ret    4
read_msrAsm ENDP

;VOID __stdcall write_msrAsm(ULONG msr, ULONG valuelow, ULONG valuehigh)
;x86 stack: msr=4 bytes | value low=4 bytes | value high=4 bytes
;           total=12 bytes
;�g�JMSR:ECX=MSR Index�BEDX:EAX=64�줸��
PUBLIC write_msrAsm
write_msrAsm PROC msr:DWORD, valuelow:DWORD, valuehigh:DWORD
    mov    ecx,msr
    mov    eax,valuelow
    mov    edx,valuehigh
    wrmsr
    ret    12
write_msrAsm ENDP

END