/* ���Y�ɦW��:PCIManagerSys.h
   �{���]�p:PIN-HSIEN CHIANG

   x86 Windows Kernel Driver:PCI/CPU/MSR/����O���餶�� */
#pragma once
#include <ntddk.h> //Windows Kernel Driver�򥻫��O�PAPI

/* x86 MASM �ץX���C���禡
   Assembly API
   Ū��CPU API */
extern ULONGLONG __stdcall read_tscAsm(VOID);
extern VOID __stdcall get_cpuidAsm(ULONG leaf, ULONG* eaxout, ULONG* ebxout, ULONG* ecxout, ULONG* edxout);
extern VOID __stdcall get_cpuidexAsm(ULONG leaf, ULONG subleaf, ULONG* eaxout, ULONG* ebxout, ULONG* ecxout, ULONG* edxout);
extern VOID __stdcall read_tscpAsm(ULONG* lowout, ULONG* highout, ULONG* auxout);
extern VOID __stdcall read_control_regsAsm(ULONG* cr0out, ULONG* cr2out, ULONG* cr3out, ULONG* cr4out, ULONG* eflagsout);
/* PCI API (8/16/32-bitŪ�g)
   Assembly I/O Port API */
extern UCHAR __stdcall in8Asm(USHORT port);
extern USHORT __stdcall in16Asm(USHORT port);
extern ULONG __stdcall in32Asm(USHORT port);
extern VOID __stdcall out8Asm(USHORT port, UCHAR value);
extern VOID __stdcall out16Asm(USHORT port, USHORT value);
extern VOID __stdcall out32Asm(USHORT port, ULONG value);
/* MSR Assembly API/MSR C API */
extern ULONGLONG __stdcall read_msrAsm(ULONG msr);
extern VOID __stdcall write_msrAsm(ULONG msr, ULONG valuelow, ULONG valuehigh);

/* PCI Scanner Constants
   PCI�̤j���y�d��:Bus 0~255�BDevice 0~31�BFunction 0~7 */
#define PCI_MAX_BUS 256
#define PCI_MAX_DEVICE 32
#define PCI_MAX_FUNCTION 8
#define PCI_MAX_BARS 6
#define PCI_MAX_CAPABILITIES 32
#define PCI_MAX_SCAN_RESULTS 1024
#define PCI_INVALID_VENDOR_ID 0xFFFF
/* PCI Configuration Registers */
#define PCI_CONFIG_ADDRESS 0xCF8
#define PCI_CONFIG_DATA 0xCFC
#define PCI_VENDOR_DEVICE_OFFSET 0x00
#define PCI_COMMAND_STATUS_OFFSET 0x04
#define PCI_REVISION_CLASS_OFFSET 0x08
#define PCI_HEADER_TYPE_OFFSET 0x0C
#define PCI_BAR0_OFFSET 0x10
#define PCI_SUBSYSTEM_OFFSET 0x2C
#define PCI_CAPABILITY_POINTER_OFFSET 0x34
#define PCI_INTERRUPT_OFFSET 0x3C
#define PCI_BRIDGE_BUS_NUMBER_OFFSET 0x18
/* PCI Header Types */
#define PCI_HEADER_TYPE_MASK 0x7F
#define PCI_HEADER_TYPE_DEVICE 0x00
#define PCI_HEADER_TYPE_BRIDGE 0x01
#define PCI_HEADER_TYPE_CARDBUS 0x02
#define PCI_HEADER_MULTI_FUNCTION 0x80
/* PCI Capability ID */
#define PCI_CAP_ID_PM 0x01
#define PCI_CAP_ID_MSI 0x05
#define PCI_CAP_ID_PCIE 0x10
#define PCI_CAP_ID_MSIX 0x11
#define PCI_COMMAND_IO_ENABLE 0x0001
#define PCI_COMMAND_MEMORY_ENABLE 0x0002
#define PCI_COMMAND_BUS_MASTER 0x0004
/* IOCTL: 0x900~0x905 PCI read/write
          0x910       PCI scan
          0x920~0x921 MSR
          0x930       CPUID
          0x931       TSC
          0x940       BAR size probe
   IOCTL�ϥ�METHOD_BUFFERED�B��Ƴz�LSystemBuffer�ǻ� */
#define IOCTL_PCI_READ8 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x900, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_READ16 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_READ32 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x902, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_WRITE8 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x903, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_WRITE16 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x904, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_WRITE32 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x905, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_MSR_READ CTL_CODE(FILE_DEVICE_UNKNOWN, 0x920, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_MSR_WRITE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x921, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_MEM_MAP CTL_CODE(FILE_DEVICE_UNKNOWN, 0x941, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_SCAN CTL_CODE(FILE_DEVICE_UNKNOWN, 0x910, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_CPUID CTL_CODE(FILE_DEVICE_UNKNOWN, 0x930, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_TSC CTL_CODE(FILE_DEVICE_UNKNOWN, 0x931, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_CPUID_EX CTL_CODE(FILE_DEVICE_UNKNOWN, 0x932, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_RDTSCP CTL_CODE(FILE_DEVICE_UNKNOWN, 0x933, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPU_CONTROL_REGS CTL_CODE(FILE_DEVICE_UNKNOWN, 0x934, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PCI_BAR_SIZE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x940, METHOD_BUFFERED, FILE_ANY_ACCESS)
/* Device Name */
#define COREDRIVER_DEVICE_NAME L"\\Device\\PCIControlSys"
#define COREDRIVER_DOS_NAME L"\\DosDevices\\PCIControlSys"

typedef struct _CPUID_REQUEST {
    ULONG Leaf;
} CPUID_REQUEST, *PCPUID_REQUEST;

typedef struct _CPUID_RESULT {
    ULONG Eax;
    ULONG Ebx;
    ULONG Ecx;
    ULONG Edx;
} CPUID_RESULT, *PCPUID_RESULT;

typedef struct _CPUID_EX_REQUEST {
    ULONG Leaf;
    ULONG SubLeaf;
} CPUID_EX_REQUEST, *PCPUID_EX_REQUEST;

typedef struct _TSC_AUX_RESULT {
    ULONGLONG Tsc;
    ULONG Aux;
} TSC_AUX_RESULT, *PTSC_AUX_RESULT;

typedef struct _CPU_CONTROL_REGS_RESULT {
    ULONG Cr0;
    ULONG Cr2;
    ULONG Cr3;
    ULONG Cr4;
    ULONG Eflags;
} CPU_CONTROL_REGS_RESULT, *PCPU_CONTROL_REGS_RESULT;

/* PCI Capability Information
   ��@PCI Capability���K�n��T */
typedef struct _PCI_CAPABILITY_INFO {
    UCHAR CapabilityId;
    UCHAR Offset;
    UCHAR Reserved[2];
    USHORT MsiMessageControl; //MSI Capability
    USHORT MsixMessageControl; //MSI-X Capability
    /* PCI Express Capability */
    UCHAR PcieVersion;
    UCHAR PcieDeviceType;
    USHORT PcieLinkStatus;
} PCI_CAPABILITY_INFO, *PPCI_CAPABILITY_INFO;

/* PCI BAR Information
   PCI BAR����l�ȡBBase Adddress�P�ݩ� */
typedef struct _PCI_BAR_INFO {
    ULONG RawValueLow; //BAR��l�C32�줸��
    ULONG RawValueHigh; //64-bit BAR����32�줸��
    ULONGLONG BaseAddress; //BAR Base Address
    ULONG Length; //BAR���סB�|�������ɬ�0
    UCHAR IsMemory; //1=Memory BAR�B0=I/O BAR
    UCHAR Is64Bit; //1=64-bit Memory BAR
    UCHAR Prefetchable; //1=Prefetchable
    UCHAR Valid; //1=��Ʀ���
} PCI_BAR_INFO, *PPCI_BAR_INFO;

/* PCI Device Information
   ��@PCI BDF�����˵��G */
typedef struct _PCI_DEVICE_INFO {
    UCHAR Bus; //BDF
    UCHAR Device;
    UCHAR Function;
    UCHAR HeaderType; //PCI Header Type
    USHORT VendorId; //PCI IDs
    USHORT DeviceId;
    UCHAR RevisionId; //Class Information
    UCHAR ProgIf;
    UCHAR SubClass;
    UCHAR ClassCode;
    USHORT SubsystemVendorId; //Subsystem
    USHORT SubsystemId;
    UCHAR InterruptLine; //Interrupt
    UCHAR InterruptPin;
    UCHAR PrimaryBus; //Bridge Bus Information
    UCHAR SecondaryBus;
    UCHAR SubordinateBus;
    UCHAR IsBridge; //Device Flags
    UCHAR IsMultiFunction;
    ULONG Command; //Command / Status
    ULONG Status;
    PCI_BAR_INFO Bars[PCI_MAX_BARS]; //BAR
    UCHAR CapabilityCount; //Capabilities
    PCI_CAPABILITY_INFO Capabilities[PCI_MAX_CAPABILITIES];
} PCI_DEVICE_INFO, *PPCI_DEVICE_INFO;

/* PCI���챽�y���G */
typedef struct _PCI_SCAN_RESULT {
    ULONG DeviceCount;
    PCI_DEVICE_INFO Devices[PCI_MAX_SCAN_RESULTS];
} PCI_SCAN_RESULT, *PPCI_SCAN_RESULT;

typedef struct _PCI_BDF_REQUEST {
    UCHAR Bus;
    UCHAR Device;
    UCHAR Function;
    UCHAR Offset;
} PCI_BDF_REQUEST, *PPCI_BDF_REQUEST;

typedef struct _PCI_BDF_WRITE8_REQUEST {
    UCHAR Bus;
    UCHAR Device;
    UCHAR Function;
    UCHAR Offset;
    UCHAR Value;
} PCI_BDF_WRITE8_REQUEST, *PPCI_BDF_WRITE8_REQUEST;

typedef struct _PCI_BDF_WRITE16_REQUEST {
    UCHAR Bus;
    UCHAR Device;
    UCHAR Function;
    UCHAR Offset;
    USHORT Value;
} PCI_BDF_WRITE16_REQUEST, *PPCI_BDF_WRITE16_REQUEST;

typedef struct _PCI_BDF_WRITE32_REQUEST {
    UCHAR Bus;
    UCHAR Device;
    UCHAR Function;
    UCHAR Offset;
    ULONG Value;
} PCI_BDF_WRITE32_REQUEST, *PPCI_BDF_WRITE32_REQUEST;

typedef struct _MSR_REQUEST {
    ULONG Msr;
} MSR_REQUEST, *PMSR_REQUEST;

typedef struct _MSR_WRITE_REQUEST {
    ULONG Msr;
    ULONGLONG ValueLow;
    ULONGLONG ValueHigh;
} MSR_WRITE_REQUEST, *PMSR_WRITE_REQUEST;

typedef struct _PCI_BAR_SIZE_REQUEST {
    UCHAR Bus;
    UCHAR Device;
    UCHAR Function;
    UCHAR BarIndex;
} PCI_BAR_SIZE_REQUEST, *PPCI_BAR_SIZE_REQUEST;

typedef struct _PCI_BAR_SIZE_RESULT {
    ULONGLONG BaseAddress; //BAR Base Address
    ULONGLONG Length;
    UCHAR IsMemory; //1=Memory BAR�B0=I/O BAR
    UCHAR Is64Bit; //1=64-bit Memory BAR
    UCHAR Prefetchable; //1=Prefetchable
    UCHAR Valid; //1=��Ʀ���
} PCI_BAR_SIZE_RESULT, *PPCI_BAR_SIZE_RESULT;

/* CPU API */
ULONGLONG read_tsc(VOID);
NTSTATUS getcpuid(ULONG leaf, PCPUID_RESULT result);
NTSTATUS getcpuid_ex(ULONG leaf, ULONG subleaf, PCPUID_RESULT result);
NTSTATUS read_tsc_aux(PTSC_AUX_RESULT result);
NTSTATUS read_cpu_control_regs(PCPU_CONTROL_REGS_RESULT result);
/* PCI Basic API */
ULONG pci_read32(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset);
USHORT pci_read16(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset);
UCHAR pci_read8(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset);
/* PCI Write API */
NTSTATUS pci_write32(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset, ULONG value);
NTSTATUS pci_write16(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset, USHORT value);
NTSTATUS pci_write8(UCHAR bus, UCHAR dev, UCHAR func, UCHAR offset, UCHAR value);
/* MSR API (rdmsr/wrmsr) */
NTSTATUS read_msr_safe(ULONG msr, PULONGLONG value);
NTSTATUS write_msr_safe(ULONG msr, ULONGLONG valuelow, ULONGLONG valuehigh);
/* Physical Memory Mapping API (MmMapIoSpace) */
PVOID map_physical(ULONGLONG phys, SIZE_T size);
VOID unmap_physical(PVOID base, SIZE_T size);
/* PCI Scanner API */
NTSTATUS pci_scan_all(PPCI_SCAN_RESULT result, ULONG maxDevices, PULONG deviceCount);
NTSTATUS pci_probe_bar_size(UCHAR bus, UCHAR dev, UCHAR func, UCHAR barIndex, PPCI_BAR_SIZE_RESULT result);
static ULONG pci_get_bar_count(UCHAR headertype);